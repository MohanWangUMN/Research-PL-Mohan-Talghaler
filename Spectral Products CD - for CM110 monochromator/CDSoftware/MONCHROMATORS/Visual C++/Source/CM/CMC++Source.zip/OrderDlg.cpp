// OrderDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "OrderDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort, gblSUnit;
extern int gblIUnit, gblOrder;
extern long gblCurWL;

/////////////////////////////////////////////////////////////////////////////
// COrderDlg dialog


COrderDlg::COrderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COrderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COrderDlg)
	m_iOrderStatus = 0;
	m_lOrderTOut = 20000;
	m_iOrder = -1;
	m_iOrderCancel = 0;
	//}}AFX_DATA_INIT
}


void COrderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COrderDlg)
	DDX_Text(pDX, IDC_ORDERSTATUS, m_iOrderStatus);
	DDX_Text(pDX, IDC_ORDERTOUT, m_lOrderTOut);
	DDX_Radio(pDX, IDC_ORDER1, m_iOrder);
	DDX_Text(pDX, IDC_ORDERCANCEL, m_iOrderCancel);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COrderDlg, CDialog)
	//{{AFX_MSG_MAP(COrderDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// COrderDlg message handlers

BOOL COrderDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	m_iOrder=gblOrder;
	//update variables
	UpdateData(FALSE);	

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void COrderDlg::OnOk() 
{
	// TODO: Add your control notification handler code here

	BYTE IDcmd, StatusB, CancelB;
	BYTE OrderB, OrderS;
	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lOrderTOut;		//2s

	OrderB=m_iOrder;
	if (OrderB==0)
		OrderS=1;
	else
		OrderS=254;
	IDcmd=51;
	openCOM(comPort);

	WriteByte( IDcmd );
	WriteByte( OrderS );

	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);
	m_iOrderStatus=StatusB;
	m_iOrderCancel=CancelB;
	//update dialog
	UpdateData(FALSE);

	if (StatusB <= 127)
	{
		gblOrder = OrderB;
		gblCurWL=0;
	}
	else
	{
		if ( (StatusB & 64)==0)
			MessageBox("An error has occurred !",
				"Status >= 128",
				MB_ICONSTOP);
		else
		{
			gblOrder = OrderB;
			gblCurWL=0;
		}
	}

	closeCOM();
	
}

/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int COrderDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void COrderDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void COrderDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int COrderDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}

