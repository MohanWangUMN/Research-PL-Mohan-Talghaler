// NWrDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "NWrDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort, gblSUnit;

/////////////////////////////////////////////////////////////////////////////
// CNWrDlg dialog


CNWrDlg::CNWrDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNWrDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNWrDlg)
	m_iNWrAddress = 0;
	m_iNWrCancel = 0;
	m_iNWrData = 0;
	m_sNWrDataHex = _T("0");
	m_iNWrStatus = 0;
	m_lNWrTOut = 2000;
	//}}AFX_DATA_INIT
}


void CNWrDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNWrDlg)
	DDX_Text(pDX, IDC_NWRADDRESS, m_iNWrAddress);
	DDX_Text(pDX, IDC_NWRCANCEL, m_iNWrCancel);
	DDX_Text(pDX, IDC_NWRDATA, m_iNWrData);
	DDX_Text(pDX, IDC_NWRDATAHEX, m_sNWrDataHex);
	DDX_Text(pDX, IDC_NWRSTATUS, m_iNWrStatus);
	DDX_Text(pDX, IDC_NWRTOUT, m_lNWrTOut);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNWrDlg, CDialog)
	//{{AFX_MSG_MAP(CNWrDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNWrDlg message handlers

void CNWrDlg::OnOk() 
{
	// TODO: Add your control notification handler code here

	BYTE idCmd, statusB, cancelB;
	int iAddrB, iDataB;
	BYTE ChkSumB;

	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lNWrTOut;		//2s
	iAddrB=m_iNWrAddress;
	iDataB=m_iNWrData;

	m_sNWrDataHex.Format("%02X", iDataB);
	UpdateData(FALSE);

	ChkSumB=iAddrB+iDataB;
	
	openCOM(comPort);

	idCmd=159;
	WriteByte( idCmd );
	WriteByte( iAddrB );
	WriteByte( iDataB );
	WriteByte( ChkSumB );

	statusB=ReadByte(timeout);
	cancelB=ReadByte(timeout);
	

	m_iNWrStatus=statusB;
	m_iNWrCancel=cancelB;

	UpdateData(FALSE);

	closeCOM();
	
}


/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CNWrDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CNWrDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CNWrDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CNWrDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}


BOOL CNWrDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	//update variables
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
