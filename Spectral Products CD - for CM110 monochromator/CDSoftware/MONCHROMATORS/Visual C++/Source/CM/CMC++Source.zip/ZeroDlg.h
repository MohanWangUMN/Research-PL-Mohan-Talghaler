#if !defined(AFX_ZERODLG_H__7D8EC5A4_13C3_4F64_BD72_064E06A4EB98__INCLUDED_)
#define AFX_ZERODLG_H__7D8EC5A4_13C3_4F64_BD72_064E06A4EB98__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ZeroDlg.h : header file
//

#include "Win32Port.h"

/////////////////////////////////////////////////////////////////////////////
// CZeroDlg dialog

class CZeroDlg : public CDialog
{
// Construction
public:
	int DecStep();
	int IncStep();
	int GotoZero();
	void Queries(WORD *OffsetM1);
	CZeroDlg(CWnd* pParent = NULL);   // standard constructor

	int ReadByte(long lTime);
	void WriteByte(int iByte);
	void closeCOM();
	int openCOM(CString comPort);

// Dialog Data
	//{{AFX_DATA(CZeroDlg)
	enum { IDD = IDD_ZERODLG };
	CButton	m_cStepUpM1;
	CButton	m_cStepDnM1;
	int		m_iOffsetM1;
	int		m_iStepM1;
	int		m_iZeroCancel;
	int		m_iZeroStatus;
	long	m_lZeroTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZeroDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	enum { SUPPRESS_READING, READ_BYTES, READ_BUFFERS } m_eReading;
	Win32Port * m_pPort;

	// Generated message map functions
	//{{AFX_MSG(CZeroDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnZero();
	afx_msg void OnStepupm1();
	afx_msg void OnStepdnm1();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZERODLG_H__7D8EC5A4_13C3_4F64_BD72_064E06A4EB98__INCLUDED_)
