// CMADlg.cpp : implementation file
//


#include <afxwin.h>
#include <process.h>
#include <cassert>
#include <sstream>
#include <mcx.h>

#include "stdafx.h"
#include "CMA.h"
#include "CMADlg.h"


#include "MyWin32Port.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CString comPort, gblSUnit;
int gblPortNo;
long gblCurWL, gblCurGr, gblCurBl;
int gblIUnit, gblOrder;
int gblSSpeed;
int gblNGrtSelted;


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMADlg dialog

CCMADlg::CCMADlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCMADlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCMADlg)
	m_lEditWL = 0;
	m_sWLUnit = _T("Current Unit");
	m_sSerial = _T("");
	m_uiGroove = 0;
	m_uiSerial = 0;
	m_uiBlaze = 0;
	m_uiGrtN = 0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCMADlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCMADlg)
	DDX_Text(pDX, IDC_EDITWL, m_lEditWL);
	DDX_Text(pDX, IDC_WL_UNIT, m_sWLUnit);
	DDX_Text(pDX, IDC_GROOVE, m_uiGroove);
	DDX_Text(pDX, IDC_SERIAL, m_uiSerial);
	DDX_Text(pDX, IDC_BLAZE, m_uiBlaze);
	DDX_Text(pDX, IDC_GRTN, m_uiGrtN);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCMADlg, CDialog)
	//{{AFX_MSG_MAP(CCMADlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(IDM_COMMANDS_C_ECHO, OnCommandsCEcho)
	ON_COMMAND(IDM_COMMANDS_C_GOTO, OnCommandsCGoto)
	ON_COMMAND(IDM_COMMANDS_C_RESET, OnCommandsCReset)
	ON_COMMAND(IDM_COMMANDS_EXIT, OnCommandsExit)
	ON_BN_CLICKED(IDC_BEXIT, OnBexit)
	ON_COMMAND(IDM_HELP_ABOUT, OnHelpAbout)
	ON_COMMAND(IDM_COMMANDS_C_SCAN, OnCommandsCScan)
	ON_COMMAND(IDM_COMMANDS_C_SPEED, OnCommandsCSpeed)
	ON_COMMAND(IDM_COMMANDS_C_SELECT, OnCommandsCSelect)
	ON_COMMAND(IDM_COMMANDS_C_QUERY, OnCommandsCQuery)
	ON_COMMAND(IDM_NOVRAM_READ, OnNovramRead)
	ON_COMMAND(IDM_NOVRAM_WRITE, OnNovramWrite)
	ON_COMMAND(IDM_COMMANDS_S_CALIBRATE, OnCommandsSCalibrate)
	ON_COMMAND(IDM_COMMANDS_S_ZERO, OnCommandsSZero)
	ON_EN_CHANGE(IDC_EDITWL, OnChangeEditwl)
	ON_COMMAND(IDM_COMMANDS_S_UNITS, OnCommandsSUnits)
	ON_COMMAND(IDM_COMMANDS_S_ORDER, OnCommandsSOrder)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCMADlg message handlers

BOOL CCMADlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

	m_dComDlg.DoModal();
	numToCOM();
	m_eReading = READ_BYTES;

	unsigned int uiMessage, cmSerial, cmGroove, cmBlaze, cmGrtN;
	unsigned int cmIUnit, cmSSpeed;
	
	openCOM(comPort);

	int rdB;
	WriteByte(27);
	rdB=ReadByte(2000);


	cmQueries(&uiMessage, 0, 2000);	//0: current wavelength
	cmQueries(&cmSerial, 19, 2000);	//19: serial number
	cmQueries(&cmGroove, 2, 2000);		//2: groove
	cmQueries(&cmBlaze, 3, 2000);		
	cmQueries(&cmGrtN, 4, 2000);
	gblNGrtSelted=cmGrtN;
	cmQueries(&cmIUnit, 14, 2000);
	gblIUnit=cmIUnit;
	iunitToSUnit();
	cmQueries(&cmSSpeed, 5, 2000);
	gblSSpeed = cmSSpeed;
	


	closeCOM();


	

	//--------------------------------
	gblCurWL=uiMessage;
	m_lEditWL=uiMessage;
	m_uiSerial=cmSerial;	
	m_uiGroove=cmGroove;
	m_uiBlaze=cmBlaze;
	m_uiGrtN=cmGrtN;
	m_sWLUnit.Format(gblSUnit);
	// Update dialog
	UpdateData(FALSE);
	//--------------------------------


	

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CCMADlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCMADlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCMADlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CCMADlg::OnBexit() 
{
	// TODO: Add your control notification handler code here
	OnOK();
}


void CCMADlg::OnCommandsExit() 
{
	// TODO: Add your command handler code here
	OnOK();
}


/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CCMADlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CCMADlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CCMADlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CCMADlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}


void CCMADlg::cmQueries(unsigned int *uiMessage,int iQueryB,long lTime)
{
	BYTE idCmd, statusB, cancelB;
	int iMessage[2];
	idCmd=56;
	WriteByte( idCmd );
	WriteByte( iQueryB );
	iMessage[0]=ReadByte(lTime);
	iMessage[1]=ReadByte(lTime);
	statusB=ReadByte(lTime);
	cancelB=ReadByte(lTime);

	if( statusB & 0x08 )	//0: +, 1: -
		gblOrder=1;
	else
		gblOrder=0;


	*uiMessage=iMessage[0]*256+iMessage[1];
}

void CCMADlg::numToCOM()
{
	switch(gblPortNo)
	{
		case 0: comPort.Format("COM1"); break;
		case 1: comPort.Format("COM2"); break;
		case 2: comPort.Format("COM3"); break;
		case 3: comPort.Format("COM4"); break;
	}
}

void CCMADlg::iunitToSUnit()
{
	switch(gblIUnit)
	{
		case 0: gblSUnit.Format("Microns"); break;
		case 1: gblSUnit.Format("Nanometers"); break;
		case 2: gblSUnit.Format("Angstroms"); break;
	}
}


void CCMADlg::OnCommandsCGoto() 
{
	// TODO: Add your command handler code here
	m_dGotoDlg.DoModal();

	m_lEditWL=gblCurWL;
	// Update dialog
	UpdateData(FALSE);
}

void CCMADlg::OnCommandsCEcho() 
{
	// TODO: Add your command handler code here
	m_dEchoDlg.DoModal();
}

void CCMADlg::OnCommandsCReset() 
{
	// TODO: Add your command handler code here
	m_dResetDlg.DoModal();
	m_lEditWL=gblCurWL;
	// Update dialog
	UpdateData(FALSE);	
	
}


void CCMADlg::OnHelpAbout() 
{
	// TODO: Add your command handler code here
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

void CCMADlg::OnCommandsCScan() 
{
	// TODO: Add your command handler code here
	m_dScanDlg.DoModal();
	m_lEditWL=gblCurWL;
	// Update dialog
	UpdateData(FALSE);
}

void CCMADlg::OnCommandsCSpeed() 
{
	// TODO: Add your command handler code here
	m_dSpeedDlg.DoModal();
}

void CCMADlg::OnCommandsCSelect() 
{
	// TODO: Add your command handler code here
	m_dGrtSelDlg.DoModal();

	openCOM(comPort);
	unsigned int cmGroove, cmBlaze, cmIUnit;
	cmQueries(&cmGroove, 2, 2000);		//2: groove
	cmQueries(&cmBlaze, 3, 2000);		
	cmQueries(&cmIUnit, 14, 2000);

	gblIUnit=cmIUnit;
	iunitToSUnit();

	m_uiGroove=cmGroove;
	m_uiBlaze=cmBlaze;
	m_uiGrtN=gblNGrtSelted;
	m_sWLUnit.Format(gblSUnit);
	m_lEditWL=gblCurWL;
	// Update dialog
	UpdateData(FALSE);	
	
	closeCOM();
}

void CCMADlg::OnCommandsCQuery() 
{
	// TODO: Add your command handler code here
	m_dQueryDlg.DoModal();
}

void CCMADlg::OnNovramRead() 
{
	// TODO: Add your command handler code here
	m_dNRdDlg.DoModal();
	
}

void CCMADlg::OnNovramWrite() 
{
	// TODO: Add your command handler code here
	m_dNWrDlg.DoModal();	
}

void CCMADlg::OnCommandsSCalibrate() 
{
	// TODO: Add your command handler code here
	m_dCalDlg.DoModal();	

}

void CCMADlg::OnCommandsSZero() 
{
	// TODO: Add your command handler code here
	m_dZeroDlg.DoModal();
	m_lEditWL=gblCurWL;
	// Update dialog
	UpdateData(FALSE);	
}

void CCMADlg::OnChangeEditwl() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	m_dGotoDlg.DoModal();

	m_lEditWL=gblCurWL;
	// Update dialog
	UpdateData(FALSE);
}

void CCMADlg::OnCommandsSUnits() 
{
	// TODO: Add your command handler code here
	m_dUnitDlg.DoModal();
	iunitToSUnit();

	unsigned int uiMessage;
	openCOM(comPort);
	cmQueries(&uiMessage, 0, 2000);	//0: current wavelength
	closeCOM();	
	gblCurWL=uiMessage;	
	m_lEditWL=gblCurWL;
	m_sWLUnit.Format(gblSUnit);
	// Update dialog
	UpdateData(FALSE);	

}

void CCMADlg::OnCommandsSOrder() 
{
	// TODO: Add your command handler code here
	m_dOrderDlg.DoModal();
	m_lEditWL=gblCurWL;
	// Update dialog
	UpdateData(FALSE);	
	
}
