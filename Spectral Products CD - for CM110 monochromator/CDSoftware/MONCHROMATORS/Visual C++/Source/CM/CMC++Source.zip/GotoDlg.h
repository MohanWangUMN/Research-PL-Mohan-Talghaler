#if !defined(AFX_GOTODLG_H__29FF8D2A_4685_40AB_AD8E_82FBE0B9193E__INCLUDED_)
#define AFX_GOTODLG_H__29FF8D2A_4685_40AB_AD8E_82FBE0B9193E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GotoDlg.h : header file
//

#include "Win32Port.h"

/////////////////////////////////////////////////////////////////////////////
// CGotoDlg dialog

class CGotoDlg : public CDialog
{
// Construction
public:
	CGotoDlg(CWnd* pParent = NULL);   // standard constructor

	int ReadByte(long lTime);
	void WriteByte(int iByte);
	void closeCOM();
	int openCOM(CString comPort);

// Dialog Data
	//{{AFX_DATA(CGotoDlg)
	enum { IDD = IDD_GOTODLG };
	CButton	m_cOK;
	int		m_iGotoCancel;
	int		m_iGotoStatus;
	long	m_lGotoTOut;
	long	m_lGotoWL;
	CString	m_sWLUnit;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGotoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	enum { SUPPRESS_READING, READ_BYTES, READ_BUFFERS } m_eReading;
	Win32Port * m_pPort;

	// Generated message map functions
	//{{AFX_MSG(CGotoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GOTODLG_H__29FF8D2A_4685_40AB_AD8E_82FBE0B9193E__INCLUDED_)
