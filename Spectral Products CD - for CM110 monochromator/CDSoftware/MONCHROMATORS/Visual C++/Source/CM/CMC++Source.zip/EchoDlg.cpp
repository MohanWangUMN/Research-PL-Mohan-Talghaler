// EchoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "EchoDlg.h"

#include "MyWin32Port.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort;

/////////////////////////////////////////////////////////////////////////////
// CEchoDlg dialog


CEchoDlg::CEchoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEchoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEchoDlg)
	m_BEchoByte = 0;
	m_lEchoTOut = 2000;
	//}}AFX_DATA_INIT
}


void CEchoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEchoDlg)
	DDX_Text(pDX, IDC_ECHOBYTE, m_BEchoByte);
	DDX_Text(pDX, IDC_ECHOTOUT, m_lEchoTOut);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEchoDlg, CDialog)
	//{{AFX_MSG_MAP(CEchoDlg)
	ON_BN_CLICKED(IDC_ECHO, OnEcho)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEchoDlg message handlers

void CEchoDlg::OnEcho() 
{
	// TODO: Add your control notification handler code here

	BYTE echoB;
	//update variables
	UpdateData(TRUE);
	openCOM(comPort);

	WriteByte( 27 );
	echoB=ReadByte(m_lEchoTOut);
	m_BEchoByte=echoB;
	//update dialog
	UpdateData(FALSE);

	closeCOM();
}


/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CEchoDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CEchoDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CEchoDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CEchoDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}

BOOL CEchoDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	m_BEchoByte = 0;
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
