// GotoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "GotoDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort, gblSUnit;
extern long gblCurWL;

/////////////////////////////////////////////////////////////////////////////
// CGotoDlg dialog


CGotoDlg::CGotoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGotoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGotoDlg)
	m_iGotoCancel = 0;
	m_iGotoStatus = 0;
	m_lGotoTOut = 20000;
	m_lGotoWL = 0;
	m_sWLUnit = _T("");
	//}}AFX_DATA_INIT
}


void CGotoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGotoDlg)
	DDX_Control(pDX, IDC_OK, m_cOK);
	DDX_Text(pDX, IDC_GOTOCANCEL, m_iGotoCancel);
	DDX_Text(pDX, IDC_GOTOSTATUS, m_iGotoStatus);
	DDX_Text(pDX, IDC_GOTOTOUT, m_lGotoTOut);
	DDX_Text(pDX, IDC_GOTOWL, m_lGotoWL);
	DDX_Text(pDX, IDC_WLUNIT, m_sWLUnit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGotoDlg, CDialog)
	//{{AFX_MSG_MAP(CGotoDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGotoDlg message handlers

BOOL CGotoDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	m_lGotoWL=gblCurWL;
	m_sWLUnit.Format(gblSUnit);
	//update variables
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CGotoDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CGotoDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CGotoDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CGotoDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}

void CGotoDlg::OnOk() 
{
	// TODO: Add your control notification handler code here
	BYTE IDcmd, StatusB, CancelB;
	BYTE HiB, LoB;
	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lGotoTOut;		//2s
	HiB=m_lGotoWL / 256;
	LoB=m_lGotoWL - 256 * HiB;

	IDcmd=16;
	openCOM(comPort);

	WriteByte( IDcmd );
	WriteByte( HiB );
	WriteByte( LoB );

	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);
	m_iGotoStatus=StatusB;
	m_iGotoCancel=CancelB;
	//update dialog
	UpdateData(FALSE);

	if (StatusB <= 127)
	{
		gblCurWL = m_lGotoWL;
	}
	else
	{
		if ( (StatusB & 64)==0)
			MessageBox("An error has occurred !",
				"Status >= 128",
				MB_ICONSTOP);
		else
			gblCurWL = m_lGotoWL;
	}

	closeCOM();
}
