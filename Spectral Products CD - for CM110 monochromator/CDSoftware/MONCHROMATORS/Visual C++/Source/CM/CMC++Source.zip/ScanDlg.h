#if !defined(AFX_SCANDLG_H__46FC57BB_6380_4868_9EA2_C428AC717211__INCLUDED_)
#define AFX_SCANDLG_H__46FC57BB_6380_4868_9EA2_C428AC717211__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ScanDlg.h : header file
//

#include "Win32Port.h"

/////////////////////////////////////////////////////////////////////////////
// CScanDlg dialog

class CScanDlg : public CDialog
{
// Construction
public:
	CScanDlg(CWnd* pParent = NULL);   // standard constructor

	int ReadByte(long lTime);
	void WriteByte(int iByte);
	void closeCOM();
	int openCOM(CString comPort);

// Dialog Data
	//{{AFX_DATA(CScanDlg)
	enum { IDD = IDD_SCANDLG };
	CButton	m_cOK;
	CString	m_sEWLUnit;
	CString	m_sSWLUnit;
	int		m_iScanCancel;
	int		m_iScanStatus;
	long	m_lScanTOut;
	long	m_lScanWL0;
	long	m_lScanWL1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScanDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	enum { SUPPRESS_READING, READ_BYTES, READ_BUFFERS } m_eReading;
	Win32Port * m_pPort;

	// Generated message map functions
	//{{AFX_MSG(CScanDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCANDLG_H__46FC57BB_6380_4868_9EA2_C428AC717211__INCLUDED_)
