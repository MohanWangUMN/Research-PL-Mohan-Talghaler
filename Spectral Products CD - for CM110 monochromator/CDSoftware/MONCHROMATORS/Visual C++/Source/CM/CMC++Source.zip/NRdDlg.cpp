// NRdDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "NRdDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort, gblSUnit;

/////////////////////////////////////////////////////////////////////////////
// CNRdDlg dialog


CNRdDlg::CNRdDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNRdDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNRdDlg)
	m_iNRdAddress = 0;
	m_iNRdCancel = 0;
	m_iNRdData = 0;
	m_sNRdDataHex = _T("0");
	m_iNRdStatus = 0;
	m_lNRdTOut = 2000;
	//}}AFX_DATA_INIT
}


void CNRdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNRdDlg)
	DDX_Control(pDX, IDC_OK, m_cOK);
	DDX_Text(pDX, IDC_NRDADDRESS, m_iNRdAddress);
	DDX_Text(pDX, IDC_NRDCANCEL, m_iNRdCancel);
	DDX_Text(pDX, IDC_NRDDATA, m_iNRdData);
	DDX_Text(pDX, IDC_NRDDATAHEX, m_sNRdDataHex);
	DDX_Text(pDX, IDC_NRDSTATUS, m_iNRdStatus);
	DDX_Text(pDX, IDC_NRDTOUT, m_lNRdTOut);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CNRdDlg, CDialog)
	//{{AFX_MSG_MAP(CNRdDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNRdDlg message handlers

BOOL CNRdDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	//update variables
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CNRdDlg::OnOk() 
{
	// TODO: Add your control notification handler code here

	BYTE idCmd, statusB, cancelB;
	int iMessage;
	int iAddressB;

	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lNRdTOut;		//2s

	iAddressB=m_iNRdAddress;
	
	openCOM(comPort);

	idCmd=156;
	WriteByte( idCmd );
	WriteByte( iAddressB );
	
	iMessage=ReadByte(timeout);

	statusB=ReadByte(timeout);
	cancelB=ReadByte(timeout);
	
	m_iNRdData=iMessage;
	m_sNRdDataHex.Format("%02X", iMessage);

	m_iNRdStatus=statusB;
	m_iNRdCancel=cancelB;

	UpdateData(FALSE);

	closeCOM();

	//m_sNRdDataHex.Format("%04X", DataI);
	
}

/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CNRdDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CNRdDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CNRdDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CNRdDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}

