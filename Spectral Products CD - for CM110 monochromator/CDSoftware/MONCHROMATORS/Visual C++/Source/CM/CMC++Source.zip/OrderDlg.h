#if !defined(AFX_ORDERDLG_H__739035F7_F17A_4136_B804_A9D5573087D9__INCLUDED_)
#define AFX_ORDERDLG_H__739035F7_F17A_4136_B804_A9D5573087D9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OrderDlg.h : header file
//

#include "Win32Port.h"

/////////////////////////////////////////////////////////////////////////////
// COrderDlg dialog

class COrderDlg : public CDialog
{
// Construction
public:
	COrderDlg(CWnd* pParent = NULL);   // standard constructor

	int ReadByte(long lTime);
	void WriteByte(int iByte);
	void closeCOM();
	int openCOM(CString comPort);

// Dialog Data
	//{{AFX_DATA(COrderDlg)
	enum { IDD = IDD_ORDERDLG };
	int		m_iOrderStatus;
	long	m_lOrderTOut;
	int		m_iOrder;
	int		m_iOrderCancel;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(COrderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	enum { SUPPRESS_READING, READ_BYTES, READ_BUFFERS } m_eReading;
	Win32Port * m_pPort;
	// Generated message map functions
	//{{AFX_MSG(COrderDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ORDERDLG_H__739035F7_F17A_4136_B804_A9D5573087D9__INCLUDED_)
