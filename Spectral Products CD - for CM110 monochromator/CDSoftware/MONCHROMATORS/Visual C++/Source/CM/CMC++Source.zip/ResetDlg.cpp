// ResetDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "ResetDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort;
extern long gblCurWL;

/////////////////////////////////////////////////////////////////////////////
// CResetDlg dialog


CResetDlg::CResetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CResetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CResetDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CResetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CResetDlg)
	DDX_Control(pDX, IDC_PROGRESS1, m_cProgress);
	DDX_Control(pDX, IDOK, m_cOK);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CResetDlg, CDialog)
	//{{AFX_MSG_MAP(CResetDlg)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CResetDlg message handlers

BOOL CResetDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	openCOM(comPort);	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CResetDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CResetDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CResetDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CResetDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}


void CResetDlg::OnOK() 
{
	// TODO: Add extra validation here

	BYTE IDcmd, echoB;
	int i;

	m_cOK.EnableWindow(FALSE);
	m_cProgress.SetRange(0, 10);
	m_cProgress.SetPos(1);	// Clear the progress bar

	IDcmd=255;

	WriteByte( IDcmd );
	WriteByte( IDcmd );
	WriteByte( IDcmd );

	i=2;
	echoB=ReadByte(1000);
	m_cProgress.SetPos(i+1);
	do
	{
	WriteByte( 27 );
	echoB=ReadByte(500);
	m_cProgress.SetPos(i+1);
	}
	while( echoB != 27 );
	m_cProgress.SetPos(10);
	m_cOK.EnableWindow(TRUE);
	gblCurWL = 0;	

}

void CResetDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	closeCOM();
}
