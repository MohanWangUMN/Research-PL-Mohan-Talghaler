// SpeedDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "SpeedDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


extern CString comPort, gblSUnit;
extern long gblCurWL;
extern int gblSSpeed;


/////////////////////////////////////////////////////////////////////////////
// CSpeedDlg dialog


CSpeedDlg::CSpeedDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSpeedDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSpeedDlg)
	m_iSpeedCancel = 0;
	m_iSpeedNew = 0;
	m_iSpeedStatus = 0;
	m_lSpeedTOut = 2000;
	//}}AFX_DATA_INIT
}


void CSpeedDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSpeedDlg)
	DDX_Text(pDX, IDC_SPEEDCANCEL, m_iSpeedCancel);
	DDX_Text(pDX, IDC_SPEEDNEW, m_iSpeedNew);
	DDX_Text(pDX, IDC_SPEEDSTATUS, m_iSpeedStatus);
	DDX_Text(pDX, IDC_SPEEDTOUT, m_lSpeedTOut);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSpeedDlg, CDialog)
	//{{AFX_MSG_MAP(CSpeedDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpeedDlg message handlers

BOOL CSpeedDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	m_iSpeedNew=gblSSpeed;
	//update variables
	UpdateData(FALSE);

	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSpeedDlg::OnOk() 
{
	// TODO: Add your control notification handler code here

	BYTE IDcmd, StatusB, CancelB;
	BYTE HiB, LoB;
	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lSpeedTOut;		//2s
	HiB=m_iSpeedNew / 256;
	LoB=m_iSpeedNew - 256 * HiB;

	IDcmd=13;
	openCOM(comPort);

	WriteByte( IDcmd );
	WriteByte( HiB );
	WriteByte( LoB );


	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);
	m_iSpeedStatus=StatusB;
	m_iSpeedCancel=CancelB;
	//update dialog
	UpdateData(FALSE);


	if (StatusB <= 127)
	{
		gblSSpeed = m_iSpeedNew;
	}
	else
	{
		if ( (StatusB & 64)==0)
			MessageBox("An error has occurred !",
				"Status >= 128",
				MB_ICONSTOP);
		else
			gblSSpeed = m_iSpeedNew;
	}

	closeCOM();

	
}
/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CSpeedDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CSpeedDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CSpeedDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CSpeedDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}
