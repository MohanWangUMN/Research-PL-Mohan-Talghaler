// CMADlg.h : header file
//

#if !defined(AFX_CMADLG_H__4E9B54A1_08E1_464B_A7BD_12123EBE57A9__INCLUDED_)
#define AFX_CMADLG_H__4E9B54A1_08E1_464B_A7BD_12123EBE57A9__INCLUDED_

#include "ZeroDlg.h"	// Added by ClassView
#include "EchoDlg.h"	// Added by ClassView
#include "ComDlg.h"	// Added by ClassView
#include "GotoDlg.h"	// Added by ClassView
#include "ResetDlg.h"	// Added by ClassView
#include "ScanDlg.h"	// Added by ClassView
#include "SpeedDlg.h"	// Added by ClassView
#include "GrtSelDlg.h"	// Added by ClassView
#include "QueryDlg.h"	// Added by ClassView
#include "NRdDlg.h"	// Added by ClassView
#include "NWrDlg.h"	// Added by ClassView
#include "CalDlg.h"	// Added by ClassView
#include "UnitDlg.h"	// Added by ClassView
#include "OrderDlg.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


/////////////////////////////////////////////////////////////////////////////
// CCMADlg dialog

class CCMADlg : public CDialog
{
// Construction
public:
	COrderDlg m_dOrderDlg;
	CUnitDlg m_dUnitDlg;
	CZeroDlg m_dZeroDlg;
	CCalDlg m_dCalDlg;
	CNWrDlg m_dNWrDlg;
	CNRdDlg m_dNRdDlg;
	CQueryDlg m_dQueryDlg;
	CGrtSelDlg m_dGrtSelDlg;
	CSpeedDlg m_dSpeedDlg;
	CScanDlg m_dScanDlg;
	void iunitToSUnit();
	CResetDlg m_dResetDlg;
	CGotoDlg m_dGotoDlg;
	void numToCOM();
	CComDlg m_dComDlg;
	CEchoDlg m_dEchoDlg;
	void cmQueries(unsigned int  *uiMessage,int iQueryB,long lTime);
	int ReadByte(long lTime);
	void WriteByte(int iByte);
	void closeCOM();
	int openCOM(CString comPort);
	CCMADlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCMADlg)
	enum { IDD = IDD_CMA_DIALOG };
	long	m_lEditWL;
	CString	m_sWLUnit;
	CString	m_sSerial;
	UINT	m_uiGroove;
	UINT	m_uiSerial;
	UINT	m_uiBlaze;
	UINT	m_uiGrtN;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCMADlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	enum { SUPPRESS_READING, READ_BYTES, READ_BUFFERS } m_eReading;
	Win32Port * m_pPort;

	// Generated message map functions
	//{{AFX_MSG(CCMADlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnCommandsCEcho();
	afx_msg void OnCommandsCGoto();
	afx_msg void OnCommandsCReset();
	afx_msg void OnCommandsExit();
	afx_msg void OnBexit();
	afx_msg void OnHelpAbout();
	afx_msg void OnCommandsCScan();
	afx_msg void OnCommandsCSpeed();
	afx_msg void OnCommandsCSelect();
	afx_msg void OnCommandsCQuery();
	afx_msg void OnNovramRead();
	afx_msg void OnNovramWrite();
	afx_msg void OnCommandsSCalibrate();
	afx_msg void OnCommandsSZero();
	afx_msg void OnChangeEditwl();
	afx_msg void OnCommandsSUnits();
	afx_msg void OnCommandsSOrder();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CMADLG_H__4E9B54A1_08E1_464B_A7BD_12123EBE57A9__INCLUDED_)
