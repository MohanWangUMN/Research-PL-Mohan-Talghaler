#if !defined(AFX_NWRDLG_H__960653E6_A9E6_4EC2_8F7F_A1AC4A0BAE80__INCLUDED_)
#define AFX_NWRDLG_H__960653E6_A9E6_4EC2_8F7F_A1AC4A0BAE80__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NWrDlg.h : header file
//

#include "Win32Port.h"

/////////////////////////////////////////////////////////////////////////////
// CNWrDlg dialog

class CNWrDlg : public CDialog
{
// Construction
public:
	CNWrDlg(CWnd* pParent = NULL);   // standard constructor

	int ReadByte(long lTime);
	void WriteByte(int iByte);
	void closeCOM();
	int openCOM(CString comPort);

// Dialog Data
	//{{AFX_DATA(CNWrDlg)
	enum { IDD = IDD_NWRDLG };
	int		m_iNWrAddress;
	int		m_iNWrCancel;
	int		m_iNWrData;
	CString	m_sNWrDataHex;
	int		m_iNWrStatus;
	long	m_lNWrTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNWrDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	enum { SUPPRESS_READING, READ_BYTES, READ_BUFFERS } m_eReading;
	Win32Port * m_pPort;
	// Generated message map functions
	//{{AFX_MSG(CNWrDlg)
	afx_msg void OnOk();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NWRDLG_H__960653E6_A9E6_4EC2_8F7F_A1AC4A0BAE80__INCLUDED_)
