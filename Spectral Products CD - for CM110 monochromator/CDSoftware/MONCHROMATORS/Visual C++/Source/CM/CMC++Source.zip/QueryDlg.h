#if !defined(AFX_QUERYDLG_H__0020748C_EA08_4C43_AB2F_5FC878566B12__INCLUDED_)
#define AFX_QUERYDLG_H__0020748C_EA08_4C43_AB2F_5FC878566B12__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// QueryDlg.h : header file
//

#include "Win32Port.h"

/////////////////////////////////////////////////////////////////////////////
// CQueryDlg dialog

class CQueryDlg : public CDialog
{
// Construction
public:
	CQueryDlg(CWnd* pParent = NULL);   // standard constructor

	int ReadByte(long lTime);
	void WriteByte(int iByte);
	void closeCOM();
	int openCOM(CString comPort);

// Dialog Data
	//{{AFX_DATA(CQueryDlg)
	enum { IDD = IDD_QUERYDLG };
	CButton	m_cOK;
	CListBox	m_lbListQueries;
	CString	m_sCode;
	long	m_lQueryTOut;
	int		m_iData;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQueryDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	enum { SUPPRESS_READING, READ_BYTES, READ_BUFFERS } m_eReading;
	Win32Port * m_pPort;

	// Generated message map functions
	//{{AFX_MSG(CQueryDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	afx_msg void OnSelchangeListqueries();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QUERYDLG_H__0020748C_EA08_4C43_AB2F_5FC878566B12__INCLUDED_)
