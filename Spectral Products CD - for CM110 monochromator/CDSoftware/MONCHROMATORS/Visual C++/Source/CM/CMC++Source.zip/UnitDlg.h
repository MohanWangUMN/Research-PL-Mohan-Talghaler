#if !defined(AFX_UNITDLG_H__5149F7A9_7E5F_460D_B1F6_F399904BE3C2__INCLUDED_)
#define AFX_UNITDLG_H__5149F7A9_7E5F_460D_B1F6_F399904BE3C2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UnitDlg.h : header file
//

#include "Win32Port.h"

/////////////////////////////////////////////////////////////////////////////
// CUnitDlg dialog

class CUnitDlg : public CDialog
{
// Construction
public:
	CUnitDlg(CWnd* pParent = NULL);   // standard constructor

	int ReadByte(long lTime);
	void WriteByte(int iByte);
	void closeCOM();
	int openCOM(CString comPort);

// Dialog Data
	//{{AFX_DATA(CUnitDlg)
	enum { IDD = IDD_UNITDLG };
	CButton	m_cOK;
	int		m_iUnits;
	int		m_iUnitCancel;
	int		m_iUnitStatus;
	long	m_lUnitTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUnitDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	enum { SUPPRESS_READING, READ_BYTES, READ_BUFFERS } m_eReading;
	Win32Port * m_pPort;
	// Generated message map functions
	//{{AFX_MSG(CUnitDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UNITDLG_H__5149F7A9_7E5F_460D_B1F6_F399904BE3C2__INCLUDED_)
