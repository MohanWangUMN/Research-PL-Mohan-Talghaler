// CalDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "CalDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort, gblSUnit;
extern long gblCurWL;

/////////////////////////////////////////////////////////////////////////////
// CCalDlg dialog


CCalDlg::CCalDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCalDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCalDlg)
	m_iCalCancel = 0;
	m_lCalCurrentWL = 0;
	m_lCalDesiredWL = 0;
	m_iCalStatus = 0;
	m_lCalTOut = 2000;
	m_sDesiredUnit = _T("Current Unit");
	m_sCurrentUnit = _T("Current Unit");
	//}}AFX_DATA_INIT
}


void CCalDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCalDlg)
	DDX_Control(pDX, IDC_OK, m_cOK);
	DDX_Text(pDX, IDC_CALCANCEL, m_iCalCancel);
	DDX_Text(pDX, IDC_CALCURRENTWL, m_lCalCurrentWL);
	DDX_Text(pDX, IDC_CALDESIREDWL, m_lCalDesiredWL);
	DDX_Text(pDX, IDC_CALSTATUS, m_iCalStatus);
	DDX_Text(pDX, IDC_CALTOUT, m_lCalTOut);
	DDX_Text(pDX, IDC_DESIREDUNIT, m_sDesiredUnit);
	DDX_Text(pDX, IDC_CURRENTUNIT, m_sCurrentUnit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCalDlg, CDialog)
	//{{AFX_MSG_MAP(CCalDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCalDlg message handlers

void CCalDlg::OnOk() 
{
	// TODO: Add your control notification handler code here

	BYTE IDcmd, StatusB, CancelB;
	BYTE HiB, LoB;
	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lCalTOut;		//2s
	HiB=m_lCalDesiredWL / 256;
	LoB=m_lCalDesiredWL - 256 * HiB;

	IDcmd=18;
	openCOM(comPort);

	WriteByte( IDcmd );
	WriteByte( HiB );
	WriteByte( LoB );

	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);
	m_iCalStatus=StatusB;
	m_iCalCancel=CancelB;
	//update dialog
	UpdateData(FALSE);

	if (StatusB <= 127)
	{
		gblCurWL = 0;
	}
	else
	{
		if ( (StatusB & 64)==0)
			MessageBox("An error has occurred !",
				"Status >= 128",
				MB_ICONSTOP);
		else
			gblCurWL = 0;
	}

	closeCOM();
	
}


BOOL CCalDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	m_lCalCurrentWL=gblCurWL;
	m_lCalDesiredWL=gblCurWL;
	m_sCurrentUnit.Format(gblSUnit);
	m_sDesiredUnit.Format(gblSUnit);
	//update variables
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CCalDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CCalDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CCalDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CCalDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}

