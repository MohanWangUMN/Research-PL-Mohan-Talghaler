// UnitDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "UnitDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort, gblSUnit;
extern int gblIUnit;
extern long gblCurWL;

/////////////////////////////////////////////////////////////////////////////
// CUnitDlg dialog


CUnitDlg::CUnitDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUnitDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUnitDlg)
	m_iUnits = -1;
	m_iUnitCancel = 0;
	m_iUnitStatus = 0;
	m_lUnitTOut = 20000;
	//}}AFX_DATA_INIT
}


void CUnitDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUnitDlg)
	DDX_Control(pDX, IDC_OK, m_cOK);
	DDX_Radio(pDX, IDC_UNITS1, m_iUnits);
	DDX_Text(pDX, IDC_UNITCANCEL, m_iUnitCancel);
	DDX_Text(pDX, IDC_UNITSTATUS, m_iUnitStatus);
	DDX_Text(pDX, IDC_UNITTOUT, m_lUnitTOut);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUnitDlg, CDialog)
	//{{AFX_MSG_MAP(CUnitDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUnitDlg message handlers

BOOL CUnitDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	m_iUnits=gblIUnit;
	//update variables
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUnitDlg::OnOk() 
{
	// TODO: Add your control notification handler code here

	BYTE IDcmd, StatusB, CancelB;
	BYTE UnitB;
	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lUnitTOut;		//2s

	UnitB=m_iUnits;

	IDcmd=50;
	openCOM(comPort);

	WriteByte( IDcmd );
	WriteByte( UnitB );

	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);
	m_iUnitStatus=StatusB;
	m_iUnitCancel=CancelB;
	//update dialog
	UpdateData(FALSE);

	if (StatusB <= 127)
	{
		gblIUnit = UnitB;
	}
	else
	{
		if ( (StatusB & 64)==0)
			MessageBox("An error has occurred !",
				"Status >= 128",
				MB_ICONSTOP);
		else
			gblIUnit = UnitB;
	}

	closeCOM();

}

/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CUnitDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CUnitDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CUnitDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CUnitDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}

