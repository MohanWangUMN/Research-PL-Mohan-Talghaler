#if !defined(AFX_ECHODLG_H__D70EEE7D_EB28_42BA_AC0F_BA0A7BF8833F__INCLUDED_)
#define AFX_ECHODLG_H__D70EEE7D_EB28_42BA_AC0F_BA0A7BF8833F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EchoDlg.h : header file
//
#include "Win32Port.h"

/////////////////////////////////////////////////////////////////////////////
// CEchoDlg dialog

class CEchoDlg : public CDialog
{
// Construction
public:
	CEchoDlg(CWnd* pParent = NULL);   // standard constructor

	int ReadByte(long lTime);
	void WriteByte(int iByte);
	void closeCOM();
	int openCOM(CString comPort);

// Dialog Data
	//{{AFX_DATA(CEchoDlg)
	enum { IDD = IDD_ECHODLG };
	BYTE	m_BEchoByte;
	long	m_lEchoTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEchoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	enum { SUPPRESS_READING, READ_BYTES, READ_BUFFERS } m_eReading;
	Win32Port * m_pPort;
	// Generated message map functions
	//{{AFX_MSG(CEchoDlg)
	afx_msg void OnEcho();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ECHODLG_H__D70EEE7D_EB28_42BA_AC0F_BA0A7BF8833F__INCLUDED_)
