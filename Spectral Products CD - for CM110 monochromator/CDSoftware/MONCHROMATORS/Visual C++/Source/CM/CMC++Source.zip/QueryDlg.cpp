// QueryDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "QueryDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort, gblSUnit;

/////////////////////////////////////////////////////////////////////////////
// CQueryDlg dialog


CQueryDlg::CQueryDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CQueryDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CQueryDlg)
	m_sCode = _T("");
	m_lQueryTOut = 2000;
	m_iData = -1;
	//}}AFX_DATA_INIT
}


void CQueryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQueryDlg)
	DDX_Control(pDX, IDC_OK, m_cOK);
	DDX_Control(pDX, IDC_LISTQUERIES, m_lbListQueries);
	DDX_Text(pDX, IDC_QUERYCODE, m_sCode);
	DDX_Text(pDX, IDC_QUERYTOUT, m_lQueryTOut);
	DDX_Text(pDX, IDC_QUERYDATA, m_iData);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CQueryDlg, CDialog)
	//{{AFX_MSG_MAP(CQueryDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	ON_LBN_SELCHANGE(IDC_LISTQUERIES, OnSelchangeListqueries)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQueryDlg message handlers

BOOL CQueryDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;

  m_lbListQueries.AddString("Current WaveLength");    //  '0
  m_lbListQueries.AddString("Monochromator Type") ;    //  '1
  m_lbListQueries.AddString("Ruling Of Cur. Sel. Grtg") ;    //      '2
  m_lbListQueries.AddString("Blaze WLength Of Cur. Sel. Grtg") ;    // '3
  m_lbListQueries.AddString("# Of Cur. Grtg Selected") ;    // '4
  m_lbListQueries.AddString("Current Scan Speed") ;    //  '5
  m_lbListQueries.AddString("Current Step Size") ;    //   '6
  m_lbListQueries.AddString("Zero Offset M1G1") ;    //    '7
  m_lbListQueries.AddString("Zero Offset M1G2") ;    //    '8
  m_lbListQueries.AddString("Zero Offset M2G1") ;    //    '9
  m_lbListQueries.AddString("Zero Offset M2G2") ;    //    '10
  m_lbListQueries.AddString("Calibration const. G1") ;    //   '11
  m_lbListQueries.AddString("Calibration const. G2") ;    //   '12
  m_lbListQueries.AddString("# Of Grtg Installed") ;    // '13
  m_lbListQueries.AddString("Current Units Selected") ;    //  '14
  m_lbListQueries.AddString("Grating Ruling G1") ;    //   '15
  m_lbListQueries.AddString("Blaze Wavelength G1") ;    // '16
  m_lbListQueries.AddString("Grating Ruling G2") ;    //   '17
  m_lbListQueries.AddString("Blaze Wavelength G2") ;    // '18
  m_lbListQueries.AddString("Serial Number") ;    //       '19

  m_lbListQueries.SetCurSel(0);

  m_lbListQueries.GetText(m_lbListQueries.GetCurSel(), m_sCode);
  //m_Index1=m_lbListQueries.GetCurSel();	//Get Selected index

   // Update Dialog
  UpdateData(FALSE);


	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CQueryDlg::OnOk() 
{
	// TODO: Add your control notification handler code here


	BYTE idCmd, statusB, cancelB;
	int iMessage[2];
	int iQueryB;

	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lQueryTOut;		//2s

	iQueryB=m_lbListQueries.GetCurSel();	//Get Selected index
	
	openCOM(comPort);

	idCmd=56;
	WriteByte( idCmd );
	WriteByte( iQueryB );
	
	iMessage[0]=ReadByte(timeout);
	iMessage[1]=ReadByte(timeout);
	
	statusB=ReadByte(timeout);
	cancelB=ReadByte(timeout);
	
	m_iData=iMessage[0]*256+iMessage[1];
	UpdateData(FALSE);

	closeCOM();
	
}


void CQueryDlg::OnSelchangeListqueries() 
{
	// TODO: Add your control notification handler code here

	m_lbListQueries.GetText(m_lbListQueries.GetCurSel(), m_sCode);
   // Update Dialog
	UpdateData(FALSE);
	
}

/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CQueryDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CQueryDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CQueryDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CQueryDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}

