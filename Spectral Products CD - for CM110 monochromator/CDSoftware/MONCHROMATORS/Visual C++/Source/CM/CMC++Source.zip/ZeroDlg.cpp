// ZeroDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "ZeroDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


extern CString comPort, gblSUnit;
extern long gblCurWL;
extern int gblNGrtSelted;
// global, declaration in this file
int StepFrom0M1;

/////////////////////////////////////////////////////////////////////////////
// CZeroDlg dialog


CZeroDlg::CZeroDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CZeroDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CZeroDlg)
	m_iOffsetM1 = 0;
	m_iStepM1 = 0;
	m_iZeroCancel = 0;
	m_iZeroStatus = 0;
	m_lZeroTOut = 2000;
	//}}AFX_DATA_INIT
}


void CZeroDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CZeroDlg)
	DDX_Control(pDX, IDC_STEPUPM1, m_cStepUpM1);
	DDX_Control(pDX, IDC_STEPDNM1, m_cStepDnM1);
	DDX_Text(pDX, IDC_OFFSETM1, m_iOffsetM1);
	DDX_Text(pDX, IDC_STEPM1, m_iStepM1);
	DDX_Text(pDX, IDC_ZEROCANCEL, m_iZeroCancel);
	DDX_Text(pDX, IDC_ZEROSTATUS, m_iZeroStatus);
	DDX_Text(pDX, IDC_ZEROTOUT, m_lZeroTOut);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CZeroDlg, CDialog)
	//{{AFX_MSG_MAP(CZeroDlg)
	ON_BN_CLICKED(IDC_ZERO, OnZero)
	ON_BN_CLICKED(IDC_STEPUPM1, OnStepupm1)
	ON_BN_CLICKED(IDC_STEPDNM1, OnStepdnm1)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CZeroDlg message handlers

BOOL CZeroDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_eReading = READ_BYTES;
	m_iStepM1 = 0;
	
	//update variables
	UpdateData(FALSE);

	StepFrom0M1 = 0;
	WORD OffsetM1;
	Queries( &OffsetM1 );
	m_iOffsetM1 = OffsetM1;
	// Updata the dialog
	UpdateData(FALSE);

	if(gblCurWL)
	{
		if(GotoZero()==0)
			gblCurWL=0;
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CZeroDlg::OnZero() 
{
	// TODO: Add your control notification handler code here
	
	BYTE IDcmd, StatusB, CancelB;
	BYTE TurretB;
	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lZeroTOut;		//2s

	TurretB=1;
	IDcmd=52;
	openCOM(comPort);

	WriteByte( IDcmd );
	WriteByte( TurretB );


	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);
	m_iZeroStatus=StatusB;
	m_iZeroCancel=CancelB;
	//update dialog
	UpdateData(FALSE);

	closeCOM();
	
	if (StatusB <= 127)
	{
		WORD OffsetM1;
		Queries( &OffsetM1 );
		m_iOffsetM1 = OffsetM1;
		StepFrom0M1=0;
		m_iStepM1=0;
		// Update dialog
		UpdateData(FALSE);
	}
	else
	{
		if ( (StatusB & 64)==0)
		MessageBox("An error has occurred !",
			"Status >= 128",
			MB_ICONSTOP);
		else
		{
			WORD OffsetM1;
			Queries( &OffsetM1 );
			m_iOffsetM1 = OffsetM1;
			StepFrom0M1=0;
			m_iStepM1=0;
			// Update dialog
			UpdateData(FALSE);
		}
	}

}

void CZeroDlg::OnStepupm1() 
{
	// TODO: Add your control notification handler code here
	if(IncStep() == 0)
		m_iStepM1 = ++StepFrom0M1;
	// Update the dialog
	UpdateData(FALSE);
	
}

void CZeroDlg::OnStepdnm1() 
{
	// TODO: Add your control notification handler code here
	if(DecStep() == 0)
		m_iStepM1 = --StepFrom0M1;
	// Update the dialog
	UpdateData(FALSE);
	
}

/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CZeroDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CZeroDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CZeroDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CZeroDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}


void CZeroDlg::Queries(WORD *OffsetM1)
{
	long timeout;

	BYTE MIndexH, MIndexL;	// The index of current grating select.
	MIndexH=gblNGrtSelted*2;	//Number of grating selected.
	MIndexL=gblNGrtSelted*2+1;	//Number of grating selected.
	
	BYTE IDcmd, StatusB, CancelB;
	BYTE HiB, LoB;

	timeout= 2000;		//2000ms
		
	openCOM(comPort);

	IDcmd=156;
	WriteByte( IDcmd );
	WriteByte( MIndexH );
	
	HiB=ReadByte(timeout);

	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);


	IDcmd=156;
	WriteByte( IDcmd );
	WriteByte( MIndexL );
	
	LoB=ReadByte(timeout);

	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);

	*OffsetM1= HiB*256 + LoB;
	
	closeCOM();
}

int CZeroDlg::GotoZero()
{
	// Return Zero if NO error
	int rtnI;
	rtnI=128;	// Yes, error

	BYTE IDcmd, StatusB, CancelB;
	
	long timeout;
	timeout=2000;		//2000ms
	
	IDcmd=16;
	openCOM(comPort);

	WriteByte( IDcmd );
	WriteByte( 0 );
	WriteByte( 0 );

	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);

	if (StatusB <= 127)
	{
		rtnI=0;		// No error
	}
	else
	{
		if ( (StatusB & 64)==0)
		MessageBox("An error has occurred !",
			"Status >= 128",
			MB_ICONSTOP);
		else
			rtnI=0;		// No error
	}
	
	closeCOM();
	return rtnI;
}

int CZeroDlg::IncStep()
{
	// Return 0 if no error
	BYTE IDcmd, StatusB, CancelB;
	int rtnI;
	long timeout;
	
	timeout=2000;	//2000ms
	rtnI = 128;		// Yes error
	
	IDcmd=7;
	openCOM(comPort);

	WriteByte( IDcmd );
	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);	

	if (StatusB <= 127)
	{
		rtnI = 0;	// No error
	}
	else
	{
		if ( (StatusB & 64)==0)
		MessageBox("An error has occurred !",
			"Status >= 128",
			MB_ICONSTOP);
		else
			rtnI = 0;	// No error
	}
	closeCOM();
	return rtnI;
}

int CZeroDlg::DecStep()
{
	// Return 0 if no error
	BYTE IDcmd, StatusB, CancelB;
	int rtnI;
	long timeout;
	
	timeout=2000;	//2000ms
	rtnI = 128;		// Yes error
	
	IDcmd=1;
	openCOM(comPort);

	WriteByte( IDcmd );
	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);	

	if (StatusB <= 127)
	{
		rtnI = 0;	// No error
	}
	else
	{
		if ( (StatusB & 64)==0)
		MessageBox("An error has occurred !",
			"Status >= 128",
			MB_ICONSTOP);
		else
			rtnI = 0;	// No error
	}
	closeCOM();
	return rtnI;
}

void CZeroDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here

//	if (m_iStepM1 != 0)
//		GotoZero();
	
}
