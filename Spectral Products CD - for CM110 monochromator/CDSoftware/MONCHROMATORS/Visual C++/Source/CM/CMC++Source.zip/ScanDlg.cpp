// ScanDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CMA.h"
#include "ScanDlg.h"

#include "MyWin32Port.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString comPort, gblSUnit;
extern long gblCurWL;

/////////////////////////////////////////////////////////////////////////////
// CScanDlg dialog


CScanDlg::CScanDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CScanDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CScanDlg)
	m_sEWLUnit = _T("current Unit");
	m_sSWLUnit = _T("current Unit");
	m_iScanCancel = 0;
	m_iScanStatus = 0;
	m_lScanTOut = 20000;
	m_lScanWL0 = 0;
	m_lScanWL1 = 1000;
	//}}AFX_DATA_INIT
}


void CScanDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CScanDlg)
	DDX_Control(pDX, IDC_OK, m_cOK);
	DDX_Text(pDX, IDC_EWLUNIT, m_sEWLUnit);
	DDX_Text(pDX, IDC_SWLUNIT, m_sSWLUnit);
	DDX_Text(pDX, IDC_SCANCANCEL, m_iScanCancel);
	DDX_Text(pDX, IDC_SCANSTATUS, m_iScanStatus);
	DDX_Text(pDX, IDC_SCANTOUT, m_lScanTOut);
	DDX_Text(pDX, IDC_SCANWL0, m_lScanWL0);
	DDX_Text(pDX, IDC_SCANWL1, m_lScanWL1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CScanDlg, CDialog)
	//{{AFX_MSG_MAP(CScanDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScanDlg message handlers

BOOL CScanDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_eReading = READ_BYTES;
	m_lScanWL0=gblCurWL;
	m_sSWLUnit.Format(gblSUnit);
	m_sEWLUnit.Format(gblSUnit);
	//update variables
	UpdateData(FALSE);


	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CScanDlg::OnOk() 
{
	// TODO: Add your control notification handler code here
	BYTE IDcmd, StatusB, CancelB;
	BYTE HiB0, LoB0;
	BYTE HiB1, LoB1;
	long timeout;
	// Update the variable
	UpdateData(TRUE);
	timeout=m_lScanTOut;		//2s
	HiB0=m_lScanWL0 / 256;
	LoB0=m_lScanWL0 - 256 * HiB0;

	HiB1=m_lScanWL1 / 256;
	LoB1=m_lScanWL1 - 256 * HiB1;

	IDcmd=12;
	openCOM(comPort);

	WriteByte( IDcmd );
	WriteByte( HiB0 );
	WriteByte( LoB0 );

	WriteByte( HiB1 );
	WriteByte( LoB1 );


	StatusB=ReadByte(timeout);
	CancelB=ReadByte(timeout);
	m_iScanStatus=StatusB;
	m_iScanCancel=CancelB;
	//update dialog
	UpdateData(FALSE);


	if (StatusB <= 127)
	{
		gblCurWL = m_lScanWL1;
	}
	else
	{
		if ( (StatusB & 64)==0)
			MessageBox("An error has occurred !",
				"Status >= 128",
				MB_ICONSTOP);
		else
		gblCurWL = m_lScanWL1;
	}

	closeCOM();

}

/****************************************************************************
 * This function's return value is an INTEGER.  A value of zero indicates   *
 * success.  Non-zero return values indicate an error has occured.          *
 ****************************************************************************/
int CScanDlg::openCOM(CString comPort)
{
	int iRtn;
	iRtn=0;
	CString port_name;
	port_name = comPort;
	int baud_rate = 9600;
	int word_size = 8;
	int stop_bits = 1;
	int xon_xoff = 0;
	int rts_cts = 0;
	int dtr_dsr = 0;

	CString parity;
	parity = "None";
	m_pPort = new MyWin32Port( this->m_hWnd,
								   (const char *) port_name, 
			                       baud_rate, 
								   parity[ 0 ], 
								   word_size, 
								   stop_bits,
								   UNCHANGED,
								   UNCHANGED,
								   xon_xoff,
								   rts_cts,
								   dtr_dsr );
	if ( m_pPort->ErrorStatus() == RS232_SUCCESS ) 
		iRtn=0;
	else
		iRtn=1;

	return iRtn;
}


/****************************************************************************
 * CLOSE																	*
 ****************************************************************************/
void CScanDlg::closeCOM()
{
	delete m_pPort;
	m_pPort = 0;
}

/****************************************************************************
 * WriteByte(int iByte)														*
 ****************************************************************************/
void CScanDlg::WriteByte(int iByte)
{
	m_pPort->Write( iByte, 1 );
}

/****************************************************************************
 * ReadByte(int iByte)														*
 ****************************************************************************/
int CScanDlg::ReadByte(long lTime)
{
	return(m_pPort->Read( lTime ));
}
