//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_FILTERDLG_H__463A2F08_22FA_439C_9444_84D64ED4D6E7__INCLUDED_)
#define AFX_FILTERDLG_H__463A2F08_22FA_439C_9444_84D64ED4D6E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FilterDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFilterDlg dialog

class CFilterDlg : public CDialog
{
// Construction
public:
	CFilterDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFilterDlg)
	enum { IDD = IDD_FILTERDLG };
	CButton	m_cOK;
	int		m_iFilterCancel;
	int		m_iFilterStatus;
	long	m_lFilterTOut;
	CMSComm	m_Comm;
	int		m_iNewFilter;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFilterDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFilterDlg)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeNewfilter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void XmtCOM(unsigned char);
	int Buffer_Empty_Q();
	BYTE Dequeue_Buffer();
	void RcvCOM();

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILTERDLG_H__463A2F08_22FA_439C_9444_84D64ED4D6E7__INCLUDED_)
