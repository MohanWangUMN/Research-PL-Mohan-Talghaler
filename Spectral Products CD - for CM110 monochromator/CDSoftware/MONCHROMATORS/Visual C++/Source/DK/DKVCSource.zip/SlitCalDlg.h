//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_SLITCALDLG_H__F6C4FAA4_057E_4610_82CB_7E7F99EA3FA6__INCLUDED_)
#define AFX_SLITCALDLG_H__F6C4FAA4_057E_4610_82CB_7E7F99EA3FA6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SlitCalDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSlitCalDlg dialog

class CSlitCalDlg : public CDialog
{
// Construction
public:
	CSlitCalDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSlitCalDlg)
	enum { IDD = IDD_SLITCALDLG };
	CButton	m_cOK;
	CMSComm	m_Comm;
	int		m_iSlit1Cal;
	int		m_iSlit2Cal;
	int		m_iSlitCalBtn1;
	int		m_iSlitCalCancel;
	int		m_iSlitCalStatus;
	long	m_lSlitCalTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSlitCalDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSlitCalDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	afx_msg void OnSlitcalbtn1();
	afx_msg void OnSlitcalbtn2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void UpdateGblSlit( int SlitN, int SlitNew );
	CEdit m_iSlitCal[2];
	void XmtCOM( unsigned char b );
	void RcvCOM();
	BYTE Dequeue_Buffer();
	int Buffer_Empty_Q();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SLITCALDLG_H__F6C4FAA4_057E_4610_82CB_7E7F99EA3FA6__INCLUDED_)
