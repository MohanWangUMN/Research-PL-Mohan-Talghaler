//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_SLITADJDLG_H__85DADC00_A122_49B7_9D15_7C4A17196CB5__INCLUDED_)
#define AFX_SLITADJDLG_H__85DADC00_A122_49B7_9D15_7C4A17196CB5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SlitAdjDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSlitAdjDlg dialog

class CSlitAdjDlg : public CDialog
{
// Construction
public:
	CSlitAdjDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSlitAdjDlg)
	enum { IDD = IDD_SLITADJDLG };
	CMSComm	m_Comm;
	int		m_iSlitAdjCancel;
	int		m_iSlitAdjStatus;
	long	m_lSlitAdjTOut;
	int		m_iSlitsAdj;
	int		m_iSlit1Adj;
	int		m_iSlit2Adj;
	int		m_iSlitsButton1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSlitAdjDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CEdit m_iSlitAdj[3];
	// Generated message map functions
	//{{AFX_MSG(CSlitAdjDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSlit1button();
	afx_msg void OnSlit2button();
	afx_msg void OnOk();
	afx_msg void OnSlitsbutton2();
	afx_msg void OnSlitsbutton3();
	afx_msg void OnSlitsbutton1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void UpdateGblSlit( int , int );
	void XmtCOM( unsigned char );
	void RcvCOM();
	BYTE Dequeue_Buffer();
	int Buffer_Empty_Q();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SLITADJDLG_H__85DADC00_A122_49B7_9D15_7C4A17196CB5__INCLUDED_)
