//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_SPEEDDLG_H__3456629A_48B2_469D_8133_473021705BDC__INCLUDED_)
#define AFX_SPEEDDLG_H__3456629A_48B2_469D_8133_473021705BDC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SpeedDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSpeedDlg dialog

class CSpeedDlg : public CDialog
{
// Construction
public:
	CSpeedDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSpeedDlg)
	enum { IDD = IDD_SPEEDDLG };
	CMSComm	m_Comm;
	int		m_iSpeedCancel;
	int		m_iSpeedStatus;
	long	m_lSpeedNew;
	long	m_lSpeedTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSpeedDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSpeedDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void XmtCOM(unsigned char);
	int Buffer_Empty_Q();
	BYTE Dequeue_Buffer();
	void RcvCOM();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SPEEDDLG_H__3456629A_48B2_469D_8133_473021705BDC__INCLUDED_)
