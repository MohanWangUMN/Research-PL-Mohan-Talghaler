// EchoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DKA.h"
#include "EchoDlg.h"

#include <time.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEchoDlg dialog

extern int gblPortNo;
extern int count;
extern int in;
extern int out;
extern BYTE data[255];


CEchoDlg::CEchoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEchoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CEchoDlg)
	m_BEchoByte = 0;
	m_lEchoTOut = 0;
	//}}AFX_DATA_INIT
}


void CEchoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CEchoDlg)
	DDX_Text(pDX, IDC_ECHOBYTE, m_BEchoByte);
	DDX_Control(pDX, IDC_MSCOMM1, m_Comm);
	DDX_Text(pDX, IDC_ECHOTOUT, m_lEchoTOut);
	DDV_MinMaxLong(pDX, m_lEchoTOut, 0, 3599);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CEchoDlg, CDialog)
	//{{AFX_MSG_MAP(CEchoDlg)
	ON_BN_CLICKED(IDC_ECHO, OnEcho)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEchoDlg message handlers


BOOL CEchoDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_Comm.SetCommPort(gblPortNo);
	m_Comm.SetSettings("9600,n,8,1");
	m_Comm.SetRTSEnable(TRUE);
	m_Comm.SetPortOpen(TRUE);
	m_Comm.SetInputMode(1);

	count=0;
	in=0;
	out=0;

	m_lEchoTOut=2;	// Initialize to 2s.
	m_BEchoByte=0;
	// Update the dialog
	UpdateData(FALSE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

int CEchoDlg::Buffer_Empty_Q()
{
	/* Return <> 0  if buffer is empty */
	return(count == 0);	
}

BYTE CEchoDlg::Dequeue_Buffer()
{
  /* Returns a byte from queue, MUST NOT BE EMPTY! */
  count--;
  out++;
  if ( out == 255 )
	 out = 0;
  return data[out] ;
}

void CEchoDlg::RcvCOM()
{
	COleVariant myVar;
	int hr;
	long lLen=0;
	myVar=m_Comm.GetInput();
	hr=SafeArrayGetUBound(myVar.parray, 1, &lLen);
	if( hr==S_OK)
	{
		lLen++;	//upper bound is zero based index
		// lock array so you can access it
		BYTE *pAccess;
		hr=SafeArrayAccessData(myVar.parray, (void**)&pAccess);

		if(hr==S_OK)
		{
			// Make a copy of data
			// Note: Need to check that lLen is < buffer length
			// so you don't overrun the buffer.
			for( int i=0; i<lLen; i++)
			{
				if(count<255)
				{
					count++;
					in++;
					if(in==255)
					  in=0;
					data[in]=pAccess[i];
				}
			}
			// unlock the data
			SafeArrayUnaccessData(myVar.parray);
		}
	}
}

void CEchoDlg::XmtCOM(unsigned char b)
{
	CByteArray arrBytes;
	arrBytes.Add(b);
	m_Comm.SetOutput(COleVariant(arrBytes));
}

void CEchoDlg::OnEcho() 
{
	// TODO: Add your control notification handler code here
	// VB use time 2s
	BYTE EchoB, IDcmd;

    time_t start, finish;
	long timeout;
	double elapsed_time;

	// Update the variable
	UpdateData(TRUE);
	timeout=m_lEchoTOut;		//2s

	SetDlgItemText(IDC_ECHOBYTE,"0");
	
	IDcmd=27;
	XmtCOM(IDcmd);
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while((Buffer_Empty_Q())&&(elapsed_time < timeout));
	if(elapsed_time < timeout)
	{
		EchoB = Dequeue_Buffer();
		m_BEchoByte = EchoB;
		// Update the dialog
		UpdateData(FALSE);

		if(EchoB != IDcmd)
		{
			MessageBox("An error has occurred !",
				"NO EchoByte",
				MB_ICONSTOP);
		}
	}
	else
	{
		MessageBox("Timeout !",
				"Timeout",
				MB_ICONSTOP);
	}
}

void CEchoDlg::OnCancel() 
{
	// TODO: Add extra cleanup here

	CDialog::OnCancel();
}
