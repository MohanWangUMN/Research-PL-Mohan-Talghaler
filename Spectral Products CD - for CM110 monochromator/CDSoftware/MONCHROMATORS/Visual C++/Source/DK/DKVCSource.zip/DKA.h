// DKA.h : main header file for the DKA application
//

#if !defined(AFX_DKA_H__018040A6_03CD_41A7_B4FF_A424C91B7489__INCLUDED_)
#define AFX_DKA_H__018040A6_03CD_41A7_B4FF_A424C91B7489__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDKAApp:
// See DKA.cpp for the implementation of this class
//

class CDKAApp : public CWinApp
{
public:
	CDKAApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDKAApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDKAApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DKA_H__018040A6_03CD_41A7_B4FF_A424C91B7489__INCLUDED_)
