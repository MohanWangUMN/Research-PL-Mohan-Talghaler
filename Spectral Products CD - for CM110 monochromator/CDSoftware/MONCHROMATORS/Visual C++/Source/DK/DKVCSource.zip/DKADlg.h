// DKADlg.h : header file
//
//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES

#if !defined(AFX_DKADLG_H__7336FEA5_AE5D_4311_9761_1757EBA27E78__INCLUDED_)
#define AFX_DKADLG_H__7336FEA5_AE5D_4311_9761_1757EBA27E78__INCLUDED_

#include "NWrDlg.h"	// Added by ClassView
#include "EchoDlg.h"	// Added by ClassView
#include "GotoDlg.h"	// Added by ClassView
#include "ScanDlg.h"	// Added by ClassView
#include "SpeedDlg.h"	// Added by ClassView
#include "SlitAdjDlg.h"	// Added by ClassView
#include "GrtSelDlg.h"	// Added by ClassView
#include "ZeroDlg.h"	// Added by ClassView
#include "ResetDlg.h"	// Added by ClassView
#include "NRdDlg.h"	// Added by ClassView
#include "SlitCalDlg.h"	// Added by ClassView

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDKADlg dialog

#include "ComDlg.h"	// Added by ClassView
#include "CalDlg.h"	// Added by ClassView
#include "FilterDlg.h"	// Added by ClassView
class CDKADlg : public CDialog
{
// Construction
public:
	CDKADlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDKADlg)
	enum { IDD = IDD_DKA_DIALOG };
	long	m_lEditWL;
	CMSComm	m_Comm;
	CString	m_sStaticBlaze;
	CString	m_sStaticGroove;
	CString	m_sStaticGrtNum;
	CString	m_sStaticSerial;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDKADlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDKADlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBexit();
	afx_msg void OnHelpAbout();
	afx_msg void OnCommandsCEcho();
	afx_msg void OnCommandsCGoto();
	afx_msg void OnCommandsCScan();
	afx_msg void OnCommandsCSpeed();
	afx_msg void OnCommandsCSlits();
	afx_msg void OnCommandsCSelect();
	afx_msg void OnCommandsSZero();
	afx_msg void OnCommandsCReset();
	afx_msg void OnNovramRead();
	afx_msg void OnNovramWrite();
	afx_msg void OnCommandsSSlitcal();
	afx_msg void OnComportInit();
	afx_msg void OnCommandsSCalibrate();
	afx_msg void OnCommandsCFilter();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CFilterDlg m_dFilterDlg;
	CCalDlg m_dCalDlg;
	void GetSSpeed( int *SSpeed );
	void GetSlit( int SlitQ[6] );
	void NovramRd( int AddrI, int *DataI );
	void GetWave( long *lWave );
	void CloseCOM();
	void GetGrtID( int GrtID[6] );
	void GetDkSerial( int *DkSerial );
	void XmtCOM( unsigned char b );
	void RcvCOM();
	BYTE Dequeue_Buffer();
	int Buffer_Empty_Q();
	void InitCOM();
	CComDlg m_dComDlg;
	CSlitCalDlg m_dSlitCalDlg;
	CNWrDlg m_dNWrDlg;
	CNovramRdDlg m_dNovramRdDlg;
	CResetDlg m_dResetDlg;
	CZeroDlg m_dZeroDlg;
	CGrtSelDlg m_dGrtSelDlg;
	CSlitAdjDlg m_dSlitAdjDlg;
	CSpeedDlg m_dSpeedDlg;
	CScanDlg m_dScanDlg;
	CGotoDlg m_dGotoDlg;
	CEchoDlg m_dEchoDlg;
	//CFilterDlg m_dFilterDlg;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DKADLG_H__7336FEA5_AE5D_4311_9761_1757EBA27E78__INCLUDED_)
