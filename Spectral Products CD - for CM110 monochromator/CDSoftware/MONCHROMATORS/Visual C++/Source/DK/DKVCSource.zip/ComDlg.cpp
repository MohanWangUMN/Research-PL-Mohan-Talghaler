// ComDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DKA.h"
#include "ComDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CComDlg dialog

extern int gblPortNo;


CComDlg::CComDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CComDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CComDlg)
	//}}AFX_DATA_INIT
}


void CComDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CComDlg)
	DDX_Control(pDX, IDC_COMCOMBO, m_cComCombo);
	DDX_Control(pDX, IDC_MSCOMM1, m_Comm);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CComDlg, CDialog)
	//{{AFX_MSG_MAP(CComDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CComDlg message handlers


BOOL CComDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	int portN;
	RdIniFile(&portN);
	gblPortNo=portN;

	m_cComCombo.SetCurSel(gblPortNo-1);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CComDlg::OnOk() 
{
	// TODO: Add your control notification handler code here

	int portN;
	portN = m_cComCombo.GetCurSel();
	// Update the dialog
	UpdateData(FALSE);

	if(m_Comm.GetPortOpen()==TRUE)
		m_Comm.SetPortOpen(FALSE);

	m_Comm.SetCommPort(portN+1);
	m_Comm.SetSettings("9600,n,8,1");
	m_Comm.SetRTSEnable(TRUE);
	m_Comm.SetPortOpen(TRUE);
	m_Comm.SetInputMode(1);

	WrIniFile(portN+1);	//If an error has occurred, it won't get here.
	gblPortNo=portN+1;

}

void CComDlg::WrIniFile(int portN)
{
	char* pszFileName="VcDk.ini";
	CFile myFile;

	if( !myFile.Open(pszFileName, CFile::modeCreate | CFile::modeWrite) )
	{
		TRACE("Can't open file %s\n", pszFileName);
	}
	else
	{
		char szBuffer[1];
		szBuffer[0]=(portN + 0x30);	// Convert to ASCII
		myFile.Write(&szBuffer, sizeof(szBuffer));
		myFile.Close();
	}


}

void CComDlg::RdIniFile(int *portN)
{
	*portN=-1;
	char* pszFileName="VcDk.ini";	
	CFile myFile;
	long fSize;
	char szBuffer[2];

	if ( !myFile.Open(pszFileName, CFile::modeRead) )
	{
		TRACE("Can't open file %s\n", pszFileName);
	}
	else
	{
		fSize = myFile.GetLength();
		myFile.Read(szBuffer, fSize);
		szBuffer[fSize]=NULL;

		*portN=szBuffer[0]-0x30;	// Convert to integer
		myFile.Close();
	}
}
