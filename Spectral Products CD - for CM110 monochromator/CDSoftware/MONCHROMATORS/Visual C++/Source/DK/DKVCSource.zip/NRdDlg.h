//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_NOVRAMRDDLG_H__F499E1DC_881D_41A8_AA24_CC2DAEE209B4__INCLUDED_)
#define AFX_NOVRAMRDDLG_H__F499E1DC_881D_41A8_AA24_CC2DAEE209B4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NovramRdDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNovramRdDlg dialog

class CNovramRdDlg : public CDialog
{
// Construction
public:
	CNovramRdDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNovramRdDlg)
	enum { IDD = IDD_NRDDLG };
	CButton	m_cOK;
	CMSComm	m_Comm;
	int		m_iNRdAddress;
	int		m_iNRdData;
	CString	m_sNRdDataHex;
	long	m_lNRdTOut;
	int		m_iNRdCancel;
	int		m_iNRdStatus;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNovramRdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNovramRdDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void XmtCOM( unsigned char b );
	void RcvCOM();
	BYTE Dequeue_Buffer();
	int Buffer_Empty_Q();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NOVRAMRDDLG_H__F499E1DC_881D_41A8_AA24_CC2DAEE209B4__INCLUDED_)
