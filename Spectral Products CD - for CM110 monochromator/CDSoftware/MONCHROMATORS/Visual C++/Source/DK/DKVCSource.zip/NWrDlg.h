//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_NWRDLG_H__B2FD5BFB_CF2E_41FB_81A8_AA1CFD78E798__INCLUDED_)
#define AFX_NWRDLG_H__B2FD5BFB_CF2E_41FB_81A8_AA1CFD78E798__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// NWrDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CNWrDlg dialog

class CNWrDlg : public CDialog
{
// Construction
public:
	CNWrDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CNWrDlg)
	enum { IDD = IDD_NWRDLG };
	CButton	m_cOK;
	CMSComm	m_Comm;
	int		m_iNWrAddress;
	int		m_iNWrCancel;
	int		m_iNWrData;
	CString	m_sNWrDataHex;
	int		m_iNWrStatus;
	long	m_lNWrTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CNWrDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CNWrDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void XmtCOM( unsigned char b );
	void RcvCOM();
	BYTE Dequeue_Buffer();
	int Buffer_Empty_Q();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_NWRDLG_H__B2FD5BFB_CF2E_41FB_81A8_AA1CFD78E798__INCLUDED_)
