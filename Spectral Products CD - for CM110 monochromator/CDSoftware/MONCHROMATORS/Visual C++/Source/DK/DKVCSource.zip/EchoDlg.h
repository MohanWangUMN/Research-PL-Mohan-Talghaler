//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_ECHODLG_H__68048234_0D8A_4D3F_A3BC_9016B7D8A81F__INCLUDED_)
#define AFX_ECHODLG_H__68048234_0D8A_4D3F_A3BC_9016B7D8A81F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EchoDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEchoDlg dialog

class CEchoDlg : public CDialog
{
// Construction
public:
	CEchoDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CEchoDlg)
	enum { IDD = IDD_ECHODLG };
	BYTE	m_BEchoByte;
	CMSComm	m_Comm;
	long	m_lEchoTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEchoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CEchoDlg)
	afx_msg void OnEcho();
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BYTE Dequeue_Buffer();
	int Buffer_Empty_Q();
	void XmtCOM(unsigned char);
	void RcvCOM();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ECHODLG_H__68048234_0D8A_4D3F_A3BC_9016B7D8A81F__INCLUDED_)
