//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_GOTODLG_H__75EC2A53_248D_43AC_9A27_F493886C7D3C__INCLUDED_)
#define AFX_GOTODLG_H__75EC2A53_248D_43AC_9A27_F493886C7D3C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GotoDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGotoDlg dialog

class CGotoDlg : public CDialog
{
// Construction
public:
	CGotoDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGotoDlg)
	enum { IDD = IDD_GOTODLG };
	CButton	m_cOK;
	CMSComm	m_Comm;
	long	m_lGotoWL;
	int		m_iStatus;
	int		m_iCancel;
	int		m_iGotoCancel;
	int		m_iGotoStatus;
	long	m_lGotoTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGotoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGotoDlg)
	afx_msg void OnOk();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BYTE Dequeue_Buffer();
	int Buffer_Empty_Q();
	void XmtCOM(unsigned char);
	void RcvCOM();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GOTODLG_H__75EC2A53_248D_43AC_9A27_F493886C7D3C__INCLUDED_)
