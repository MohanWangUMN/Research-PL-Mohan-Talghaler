//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_ZERODLG_H__F0B77DAE_9547_4ABC_8A03_21CC21B507C4__INCLUDED_)
#define AFX_ZERODLG_H__F0B77DAE_9547_4ABC_8A03_21CC21B507C4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ZeroDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CZeroDlg dialog

class CZeroDlg : public CDialog
{
// Construction
public:
	CZeroDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CZeroDlg)
	enum { IDD = IDD_ZERODLG };
	CButton	m_cStepDnM1;
	CButton	m_cStepUpM1;
	CMSComm	m_Comm;
	int		m_iOffsetM1;
	int		m_iStepM1;
	int		m_iZeroCancel;
	int		m_iZeroStatus;
	long	m_lZeroTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CZeroDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CZeroDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnZero();
	afx_msg void OnStepupm1();
	afx_msg void OnStepdnm1();
	virtual void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int StepUpDn( BYTE Cmd );
	void Queries( WORD * OffsetM1 );
	int GotoZero();
	void XmtCOM( unsigned char );
	void RcvCOM();
	BYTE Dequeue_Buffer();
	int Buffer_Empty_Q();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ZERODLG_H__F0B77DAE_9547_4ABC_8A03_21CC21B507C4__INCLUDED_)
