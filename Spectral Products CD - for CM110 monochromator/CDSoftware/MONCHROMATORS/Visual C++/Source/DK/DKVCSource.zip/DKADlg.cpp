// DKADlg.cpp : implementation file
//

#include "stdafx.h"
#include "DKA.h"
#include "DKADlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

// Global variables
char gblSerial[5];
int gblInitCom;
int gblNGrtInstd;	//Number of gratings installed on turret#1
long gblNGrtSelted;	//Number of grating selected.
long gblCurWL, gblCurGr, gblCurBl;
int gblPortNo;
int gblSSpeed;
int gblType;		//0: single, 1: Additive dispersion, 254: Subtractive dps.
int gblAddr;
int gblS1, gblS2, gblS3;	//S1: Entrance slit, S2: Exit, S3: Middle.
int gblNovAdd29;	//Dk configuration byte.
int gblFilter;

int count;
int in;
int out;
BYTE data[255];

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDKADlg dialog

CDKADlg::CDKADlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDKADlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDKADlg)
	m_lEditWL = 10000;
	m_sStaticBlaze = _T("301");
	m_sStaticGroove = _T("1201");
	m_sStaticGrtNum = _T("0");
	m_sStaticSerial = _T("12345");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDKADlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDKADlg)
	DDX_Text(pDX, IDC_EDITWL, m_lEditWL);
	DDV_MinMaxLong(pDX, m_lEditWL, 0, 16777215);
	DDX_Control(pDX, IDC_MSCOMM1, m_Comm);
	DDX_Text(pDX, IDC_STATICBLAZE, m_sStaticBlaze);
	DDX_Text(pDX, IDC_STATICGROOVE, m_sStaticGroove);
	DDX_Text(pDX, IDC_STATICGRTNUM, m_sStaticGrtNum);
	DDX_Text(pDX, IDC_STATICSERIAL, m_sStaticSerial);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDKADlg, CDialog)
	//{{AFX_MSG_MAP(CDKADlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BEXIT, OnBexit)
	ON_COMMAND(IDM_HELP_ABOUT, OnHelpAbout)
	ON_COMMAND(IDM_COMMANDS_C_ECHO, OnCommandsCEcho)
	ON_COMMAND(IDM_COMMANDS_C_GOTO, OnCommandsCGoto)
	ON_COMMAND(IDM_COMMANDS_C_SCAN, OnCommandsCScan)
	ON_COMMAND(IDM_COMMANDS_C_SPEED, OnCommandsCSpeed)
	ON_COMMAND(IDM_COMMANDS_C_SLITS, OnCommandsCSlits)
	ON_COMMAND(IDM_COMMANDS_C_SELECT, OnCommandsCSelect)
	ON_COMMAND(IDM_COMMANDS_S_ZERO, OnCommandsSZero)
	ON_COMMAND(IDM_COMMANDS_C_RESET, OnCommandsCReset)
	ON_COMMAND(IDM_NOVRAM_READ, OnNovramRead)
	ON_COMMAND(IDM_NOVRAM_WRITE, OnNovramWrite)
	ON_COMMAND(IDM_COMMANDS_S_SLITCAL, OnCommandsSSlitcal)
	ON_COMMAND(IDM_COMPORT_INIT, OnComportInit)
	ON_COMMAND(IDM_COMMANDS_S_CALIBRATE, OnCommandsSCalibrate)
	ON_COMMAND(IDM_COMMANDS_EXIT, OnBexit)
	ON_COMMAND(IDM_COMMANDS_C_FILTER, OnCommandsCFilter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDKADlg message handlers

BOOL CDKADlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	m_dComDlg.DoModal();
	
	int DkSerB, GrtID[6], SlitQ[6];
	int DataI, SSpeed;
	long lWave;
	InitCOM();
	GetDkSerial( &DkSerB );
	GetGrtID( GrtID );
	GetWave( &lWave );
	NovramRd(29, &DataI);
	GetSlit( SlitQ );
	GetSSpeed( &SSpeed );
	CloseCOM();

	gblNovAdd29=DataI;
	gblNGrtInstd=GrtID[0];
	gblNGrtSelted=GrtID[1];
	gblCurGr=GrtID[2]*256 + GrtID[3];
	gblCurBl=GrtID[4]*256 + GrtID[5];

	gblCurWL=lWave;

	gblS1=SlitQ[0]*256+SlitQ[1];
	gblS2=SlitQ[2]*256+SlitQ[3];
	gblS3=SlitQ[4]*256+SlitQ[5];

	gblSSpeed = SSpeed;

	gblFilter=1;

	//--------------------------------
	m_sStaticGroove.Format("%d", gblCurGr);
	m_sStaticBlaze.Format("%d", gblCurBl);
	m_sStaticGrtNum.Format("%d", gblNGrtSelted);
	m_sStaticSerial.Format("%d", DkSerB);
	m_lEditWL=gblCurWL;
	// Update dialog
	UpdateData(FALSE);
	//--------------------------------

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDKADlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDKADlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDKADlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDKADlg::OnCommandsCGoto() 
{
	// TODO: Add your command handler code here
	m_dGotoDlg.DoModal();
	m_lEditWL=gblCurWL;
	// Update the dialog
	UpdateData(FALSE);	
	
}

void CDKADlg::OnCommandsCScan() 
{
	// TODO: Add your command handler code here
	m_dScanDlg.DoModal();
	m_lEditWL=gblCurWL;
	// Update the dialog
	UpdateData(FALSE);	
}

void CDKADlg::OnCommandsCSpeed() 
{
	// TODO: Add your command handler code here
	m_dSpeedDlg.DoModal();
	
}

void CDKADlg::OnCommandsCSlits() 
{
	// TODO: Add your command handler code here
	m_dSlitAdjDlg.DoModal();

}

void CDKADlg::OnCommandsCSelect() 
{
	// TODO: Add your command handler code here
	m_dGrtSelDlg.DoModal();

	int GrtID[6], SlitQ[6];
	int SSpeed;
	long lWave;
	InitCOM();
	GetGrtID( GrtID );
	GetWave( &lWave );
	GetSlit( SlitQ );
	GetSSpeed( &SSpeed );
	CloseCOM();

	gblNGrtInstd=GrtID[0];
	gblNGrtSelted=GrtID[1];
	gblCurGr=GrtID[2]*256 + GrtID[3];
	gblCurBl=GrtID[4]*256 + GrtID[5];

	gblCurWL=lWave;

	gblS1=SlitQ[0]*256+SlitQ[1];
	gblS2=SlitQ[2]*256+SlitQ[3];
	gblS3=SlitQ[4]*256+SlitQ[5];

	gblSSpeed = SSpeed;

	//--------------------------------
	m_sStaticGroove.Format("%d", gblCurGr);
	m_sStaticBlaze.Format("%d", gblCurBl);
	m_sStaticGrtNum.Format("%d", gblNGrtSelted);
	m_lEditWL=gblCurWL;
	// Update dialog
	UpdateData(FALSE);
	//--------------------------------
	
}


void CDKADlg::OnCommandsCEcho() 
{
	// TODO: Add your command handler code here

	m_dEchoDlg.DoModal();
}


void CDKADlg::OnCommandsCReset() 
{
	// TODO: Add your command handler code here

	m_dResetDlg.DoModal();	
}


void CDKADlg::OnCommandsSCalibrate() 
{
	// TODO: Add your command handler code here

	m_dCalDlg.DoModal();

}

void CDKADlg::OnCommandsSSlitcal() 
{
	// TODO: Add your command handler code here

	m_dSlitCalDlg.DoModal();	
}


void CDKADlg::OnCommandsSZero() 
{
	// TODO: Add your command handler code here
	m_dZeroDlg.DoModal();
	m_lEditWL=gblCurWL;
	// Update the dialog
	UpdateData(FALSE);	

}


void CDKADlg::OnBexit() 
{
	// TODO: Add your control notification handler code here

	OnOK();
}


void CDKADlg::OnNovramRead() 
{
	// TODO: Add your command handler code here

	//Write to dialog
	//m_dNovramRdDlg.m_lNovramRdTOut = 10;
	m_dNovramRdDlg.DoModal();
}


void CDKADlg::OnNovramWrite() 
{
	// TODO: Add your command handler code here

	m_dNWrDlg.DoModal();

}


void CDKADlg::OnComportInit() 
{
	// TODO: Add your command handler code here

	m_dComDlg.DoModal();

}


void CDKADlg::OnHelpAbout() 
{
	// TODO: Add your command handler code here

	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}


void CDKADlg::InitCOM()
{
	m_Comm.SetCommPort(gblPortNo);
	m_Comm.SetSettings("9600,n,8,1");
	m_Comm.SetRTSEnable(TRUE);
	m_Comm.SetPortOpen(TRUE);
	m_Comm.SetInputMode(1);

	count=0;
	in=0;
	out=0;
}

void CDKADlg::CloseCOM()
{
	m_Comm.SetPortOpen(FALSE);
}

int CDKADlg::Buffer_Empty_Q()
{
	/* Return <> 0  if buffer is empty */
	return(count == 0);	
}

BYTE CDKADlg::Dequeue_Buffer()
{
  /* Returns a byte from queue, MUST NOT BE EMPTY! */
  count--;
  out++;
  if ( out == 255 )
	 out = 0;
  return data[out] ;
}

void CDKADlg::RcvCOM()
{
	COleVariant myVar;
	int hr;
	long lLen=0;
	myVar=m_Comm.GetInput();
	hr=SafeArrayGetUBound(myVar.parray, 1, &lLen);
	if( hr==S_OK)
	{
		lLen++;	//upper bound is zero based index
		// lock array so you can access it
		BYTE *pAccess;
		hr=SafeArrayAccessData(myVar.parray, (void**)&pAccess);

		if(hr==S_OK)
		{
			// Make a copy of data
			// Note: Need to check that lLen is < buffer length
			// so you don't overrun the buffer.
			for( int i=0; i<lLen; i++)
			{
				if(count<255)
				{
					count++;
					in++;
					if(in==255)
					  in=0;
					data[in]=pAccess[i];
				}
			}
			// unlock the data
			SafeArrayUnaccessData(myVar.parray);
		}
	}
}

void CDKADlg::XmtCOM(unsigned char b)
{
	CByteArray arrBytes;
	arrBytes.Add(b);
	m_Comm.SetOutput(COleVariant(arrBytes));
}


void CDKADlg::GetDkSerial(int *DkSerial)
{
	BYTE IDcmd, EchoB, StatusB, CancelB;
	
	char DkA[5];
	int serialI;

	time_t start, finish;
	long timeout;
	double elapsed_time;
	timeout= 2;		//2s
	
	*DkSerial = 0;
	IDcmd=33;
	XmtCOM(IDcmd);
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while((Buffer_Empty_Q())&&(elapsed_time < timeout));
	if(elapsed_time < timeout)
	{
		EchoB=Dequeue_Buffer();
		if(EchoB != IDcmd)
		{
			MessageBox("An error has occurred !",
				"NO EchoByte",
				MB_ICONSTOP);
		}
		for( int i=0; i<5; i++ )
		{
			while(Buffer_Empty_Q())
				RcvCOM();
			DkA[i]=Dequeue_Buffer();
		}

		while(Buffer_Empty_Q())
			RcvCOM();
		StatusB=Dequeue_Buffer();
		while(Buffer_Empty_Q())
			RcvCOM();
		CancelB=Dequeue_Buffer();

		char *pDkSerB;
		pDkSerB=DkA;
		serialI=atoi(pDkSerB);
		*DkSerial = serialI;
	}
	else
	{
		MessageBox("Timeout !", "Timeout", MB_ICONSTOP);
	}

}


void CDKADlg::GetGrtID(int GrtID[6])
{
	BYTE IDcmd, EchoB, StatusB, CancelB;
	
	time_t start, finish;
	long timeout;
	double elapsed_time;
	timeout= 2;		//2s

	IDcmd=19;
	XmtCOM(IDcmd);
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while((Buffer_Empty_Q())&&(elapsed_time < timeout));
	if(elapsed_time < timeout)
	{
		EchoB=Dequeue_Buffer();
		if(EchoB != IDcmd)
		{
			MessageBox("An error has occurred !",
				"NO EchoByte",
				MB_ICONSTOP);
		}
		for( int i=0; i<6; i++ )
		{
			while(Buffer_Empty_Q())
				RcvCOM();
			GrtID[i]=Dequeue_Buffer();
		}

		while(Buffer_Empty_Q())
			RcvCOM();
		StatusB=Dequeue_Buffer();
		while(Buffer_Empty_Q())
			RcvCOM();
		CancelB=Dequeue_Buffer();
	}
	else
	{
		MessageBox("Timeout !", "Timeout", MB_ICONSTOP);
	}

}


void CDKADlg::GetWave(long *lWave)
{
	BYTE IDcmd, EchoB, StatusB, CancelB;
	int iWave[3];
	
	time_t start, finish;
	long timeout;
	double elapsed_time;
	timeout= 2;		//2s

	*lWave=0;
	IDcmd=29;
	XmtCOM(IDcmd);
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while((Buffer_Empty_Q())&&(elapsed_time < timeout));
	if(elapsed_time < timeout)
	{
		EchoB=Dequeue_Buffer();
		if(EchoB != IDcmd)
		{
			MessageBox("An error has occurred !",
				"NO EchoByte",
				MB_ICONSTOP);
		}
		for( int i=0; i<3; i++ )
		{
			while(Buffer_Empty_Q())
				RcvCOM();
			iWave[i]=Dequeue_Buffer();
		}

		while(Buffer_Empty_Q())
			RcvCOM();
		StatusB=Dequeue_Buffer();
		while(Buffer_Empty_Q())
			RcvCOM();
		CancelB=Dequeue_Buffer();
		*lWave=iWave[0]*65536+iWave[1]*256+iWave[2];
	}
	else
	{
		MessageBox("Timeout !", "Timeout", MB_ICONSTOP);
	}

}


void CDKADlg::NovramRd(int AddrI, int *DataI)
{
	BYTE IDcmd, EchoB, StatusB, CancelB;
	BYTE HiB, LoB;

	time_t start, finish;
	long timeout;
	double elapsed_time;
	
	timeout=2;		//2s
	
	IDcmd=56;
	XmtCOM(IDcmd);
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while((Buffer_Empty_Q())&&(elapsed_time < timeout));
	if(elapsed_time < timeout)
	{
		EchoB=Dequeue_Buffer();
		if(EchoB != IDcmd)
		{
			MessageBox("An error has occurred !",
				"NO EchoByte",
				MB_ICONSTOP);
		}

		XmtCOM(AddrI);

		while(Buffer_Empty_Q())
			RcvCOM();
		HiB=Dequeue_Buffer();
		while(Buffer_Empty_Q())
			RcvCOM();
		LoB=Dequeue_Buffer();

		while(Buffer_Empty_Q())
			RcvCOM();
		StatusB=Dequeue_Buffer();

		while(Buffer_Empty_Q())
			RcvCOM();
		CancelB=Dequeue_Buffer();
		
		*DataI=HiB*256+LoB;

		if (StatusB <= 127)
		{}
		else
		{
			if ( (StatusB & 64)==0)
			MessageBox("An error has occurred !",
				"Status >= 128",
				MB_ICONSTOP);
			else
			{}
		}
	
	}
	else
	{
		MessageBox("Timeout !", "Timeout", MB_ICONSTOP);
	}

}


void CDKADlg::GetSlit(int SlitQ[])
{
	BYTE IDcmd, EchoB, StatusB, CancelB;
	int Dk242;	//0: Dk240, 2: Dk242
	
	time_t start, finish;
	long timeout;
	double elapsed_time;
	timeout= 2;		//2s

	Dk242=(gblNovAdd29 & 0x2);
	IDcmd=30;
	XmtCOM(IDcmd);
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while((Buffer_Empty_Q())&&(elapsed_time < timeout));
	if(elapsed_time < timeout)
	{
		EchoB=Dequeue_Buffer();
		if(EchoB != IDcmd)
		{
			MessageBox("An error has occurred !",
				"NO EchoByte",
				MB_ICONSTOP);
		}
		if(Dk242)
		{
			for( int i=0; i<6; i++ )
			{
				while(Buffer_Empty_Q())
					RcvCOM();
				SlitQ[i]=Dequeue_Buffer();
			}
		}
		else	//Dk240
		{
			for( int i=0; i<4; i++ )
			{
				while(Buffer_Empty_Q())
					RcvCOM();
				SlitQ[i]=Dequeue_Buffer();
			}
			SlitQ[4]=0; SlitQ[5]=50;
		}
		while(Buffer_Empty_Q())
			RcvCOM();
		StatusB=Dequeue_Buffer();
		while(Buffer_Empty_Q())
			RcvCOM();
		CancelB=Dequeue_Buffer();
	}
	else
	{
		MessageBox("Timeout !", "Timeout", MB_ICONSTOP);
	}

}

void CDKADlg::GetSSpeed(int *SSpeed)
{
	BYTE IDcmd, EchoB, StatusB, CancelB;
	int iSSpeed[2];
	
	time_t start, finish;
	long timeout;
	double elapsed_time;
	timeout= 2;		//2s

	*SSpeed=0;
	IDcmd=21;
	XmtCOM(IDcmd);
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while((Buffer_Empty_Q())&&(elapsed_time < timeout));
	if(elapsed_time < timeout)
	{
		EchoB=Dequeue_Buffer();
		if(EchoB != IDcmd)
		{
			MessageBox("An error has occurred !",
				"NO EchoByte",
				MB_ICONSTOP);
		}
		for( int i=0; i<2; i++ )
		{
			while(Buffer_Empty_Q())
				RcvCOM();
			iSSpeed[i]=Dequeue_Buffer();
		}

		while(Buffer_Empty_Q())
			RcvCOM();
		StatusB=Dequeue_Buffer();
		while(Buffer_Empty_Q())
			RcvCOM();
		CancelB=Dequeue_Buffer();
		*SSpeed=iSSpeed[0]*256+iSSpeed[1];
	}
	else
	{
		MessageBox("Timeout !", "Timeout", MB_ICONSTOP);
	}

}

void CDKADlg::OnCommandsCFilter() 
{
	// TODO: Add your command handler code here

	m_dFilterDlg.DoModal();
	
}
