// SlitAdjDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DKA.h"
#include "SlitAdjDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSlitAdjDlg dialog

extern int gblPortNo;
extern int count;
extern int in;
extern int out;
extern BYTE data[255];
extern int gblS1, gblS2;


CSlitAdjDlg::CSlitAdjDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSlitAdjDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSlitAdjDlg)
	m_iSlitAdjCancel = 0;
	m_iSlitAdjStatus = 0;
	m_lSlitAdjTOut = 2;
	m_iSlitsAdj = 0;
	m_iSlit1Adj = 0;
	m_iSlit2Adj = 0;
	m_iSlitsButton1 = -1;
	//}}AFX_DATA_INIT
}


void CSlitAdjDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSlitAdjDlg)
	DDX_Control(pDX, IDC_MSCOMM1, m_Comm);
	DDX_Text(pDX, IDC_SLITADJCANCEL, m_iSlitAdjCancel);
	DDX_Text(pDX, IDC_SLITADJSTATUS, m_iSlitAdjStatus);
	DDX_Text(pDX, IDC_SLITADJTOUT, m_lSlitAdjTOut);
	DDX_Text(pDX, IDC_SLITSADJ, m_iSlitsAdj);
	DDV_MinMaxInt(pDX, m_iSlitsAdj, 10, 5000);
	DDX_Text(pDX, IDC_SLIT1ADJ, m_iSlit1Adj);
	DDV_MinMaxInt(pDX, m_iSlit1Adj, 10, 5000);
	DDX_Text(pDX, IDC_SLIT2ADJ, m_iSlit2Adj);
	DDX_Radio(pDX, IDC_SLITSBUTTON1, m_iSlitsButton1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSlitAdjDlg, CDialog)
	//{{AFX_MSG_MAP(CSlitAdjDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	ON_BN_CLICKED(IDC_SLITSBUTTON2, OnSlitsbutton2)
	ON_BN_CLICKED(IDC_SLITSBUTTON3, OnSlitsbutton3)
	ON_BN_CLICKED(IDC_SLITSBUTTON1, OnSlitsbutton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSlitAdjDlg message handlers

BOOL CSlitAdjDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_Comm.SetCommPort(gblPortNo);
	m_Comm.SetSettings("9600,n,8,1");
	m_Comm.SetRTSEnable(TRUE);
	m_Comm.SetPortOpen(TRUE);
	m_Comm.SetInputMode(1);

	count=0;
	in=0;
	out=0;
		
	// m_iSlitAdj[3]	Slits:0, S1: 1, S2: 2
	m_iSlitAdj[0].SubclassDlgItem(IDC_SLITSADJ, this);
	m_iSlitAdj[1].SubclassDlgItem(IDC_SLIT1ADJ, this);
	m_iSlitAdj[2].SubclassDlgItem(IDC_SLIT2ADJ, this);

	m_iSlitsButton1=0;
	
	m_iSlitsAdj = gblS2;
	m_iSlit1Adj = gblS1;
	m_iSlit2Adj = gblS2;
	// Update the dialog
	UpdateData(FALSE);
	OnSlitsbutton1();

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

int CSlitAdjDlg::Buffer_Empty_Q()
{
	/* Return <> 0  if buffer is empty */
	return(count == 0);	
}


BYTE CSlitAdjDlg::Dequeue_Buffer()
{
  /* Returns a byte from queue, MUST NOT BE EMPTY! */
  count--;
  out++;
  if ( out == 255 )
	 out = 0;
  return data[out] ;
}

void CSlitAdjDlg::RcvCOM()
{
	COleVariant myVar;
	int hr;
	long lLen=0;
	myVar=m_Comm.GetInput();
	hr=SafeArrayGetUBound(myVar.parray, 1, &lLen);
	if( hr==S_OK)
	{
		lLen++;	//upper bound is zero based index
		// lock array so you can access it
		BYTE *pAccess;
		hr=SafeArrayAccessData(myVar.parray, (void**)&pAccess);

		if(hr==S_OK)
		{
			// Make a copy of data
			// Note: Need to check that lLen is < buffer length
			// so you don't overrun the buffer.
			for( int i=0; i<lLen; i++)
			{
				if(count<255)
				{
					count++;
					in++;
					if(in==255)
					  in=0;
					data[in]=pAccess[i];
				}
			}
			// unlock the data
			SafeArrayUnaccessData(myVar.parray);
		}
	}
}


void CSlitAdjDlg::XmtCOM(unsigned char b)
{
	CByteArray arrBytes;
	arrBytes.Add(b);
	m_Comm.SetOutput(COleVariant(arrBytes));
}


void CSlitAdjDlg::OnSlitsbutton1() 
{
	// TODO: Add your control notification handler code here
		m_iSlitAdj[0].EnableWindow(TRUE);
		m_iSlitAdj[1].EnableWindow(FALSE);
		m_iSlitAdj[2].EnableWindow(FALSE);
		m_iSlitsButton1=0;
}


void CSlitAdjDlg::OnSlitsbutton2() 
{
	// TODO: Add your control notification handler code here
		m_iSlitAdj[0].EnableWindow(FALSE);
		m_iSlitAdj[1].EnableWindow(TRUE);
		m_iSlitAdj[2].EnableWindow(FALSE);
		m_iSlitsButton1=1;
}


void CSlitAdjDlg::OnSlitsbutton3() 
{
	// TODO: Add your control notification handler code here
		m_iSlitAdj[0].EnableWindow(FALSE);
		m_iSlitAdj[1].EnableWindow(FALSE);
		m_iSlitAdj[2].EnableWindow(TRUE);
		m_iSlitsButton1=2;
}


void CSlitAdjDlg::OnOk() 
{
	// TODO: Add your control notification handler code here
	
	BYTE IDcmd, EchoB, StatusB, CancelB;
	BYTE HiB, LoB;
	int iSlitNew;

	time_t start, finish;
	long timeout;
	double elapsed_time;


	// Update the variable
	UpdateData(TRUE);
	timeout=m_lSlitAdjTOut;		//2s

	SetDlgItemText(IDC_SLITADJSTATUS,"0");
	SetDlgItemText(IDC_SLITADJCANCEL,"0");

	switch(m_iSlitsButton1)
	{
	case 0:
		IDcmd=14;	// All Slits
		iSlitNew = m_iSlitsAdj;
		break;
	case 1:
		IDcmd=31;	// Entrance slit (S1)
		iSlitNew = m_iSlit1Adj;
		break;
	case 2:
		IDcmd=32;	// Exit slit (S2)
		iSlitNew = m_iSlit2Adj;
		break;
	default:
		IDcmd=14;	// All Slits
		iSlitNew = m_iSlitsAdj;
		break;
	}
	// Update the variable
	UpdateData(TRUE);

	XmtCOM(IDcmd);
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while((Buffer_Empty_Q())&&(elapsed_time < timeout));
	if(elapsed_time < timeout)
	{
		EchoB=Dequeue_Buffer();
		if(EchoB != IDcmd)
		{
			MessageBox("An error has occurred !",
				"NO EchoByte",
				MB_ICONSTOP);
		}

		HiB=iSlitNew / 256;
		LoB=(iSlitNew - 256 * HiB);
		
		XmtCOM(HiB);	XmtCOM(LoB);

		while(Buffer_Empty_Q())
			RcvCOM();
		StatusB=Dequeue_Buffer();
		//m_iSlitAdjStatus=StatusB;
		// Update dialog
		//UpdateData(FALSE);

		while(Buffer_Empty_Q())
			RcvCOM();
		CancelB=Dequeue_Buffer();
		
		//-----------------------------
		//A bug in DK. An extra StatusB if the same slitw was issued
		if( CancelB!=24 )
		{
			while(Buffer_Empty_Q())
				RcvCOM();
			CancelB=Dequeue_Buffer();
		}
		//-----------------------------
		
		m_iSlitAdjStatus=StatusB;
		m_iSlitAdjCancel=CancelB;
		// Update dialog
		UpdateData(FALSE);

		if (StatusB <= 127)
		{
			UpdateGblSlit( m_iSlitsButton1, iSlitNew );
		}
		else
		{
			if ( (StatusB & 64)==0)
			MessageBox("An error has occurred !",
				"Status >= 128",
				MB_ICONSTOP);
			else
				UpdateGblSlit( m_iSlitsButton1, iSlitNew );
		}
	
	}
	else
	{
		MessageBox("Timeout !", "Timeout", MB_ICONSTOP);
	}

}


void CSlitAdjDlg::UpdateGblSlit(int SlitN, int SlitNew)
{
	switch(SlitN)
	{
	case 0:
		gblS1 = SlitNew;
		gblS2 = SlitNew;
		m_iSlit1Adj = SlitNew;
		m_iSlit2Adj = SlitNew;
		break;
	case 1:
		gblS1 = SlitNew;
		break;
	case 2:
		gblS2 = SlitNew;
		m_iSlitsAdj = SlitNew;
		break;
	default:
		gblS1 = SlitNew;
		gblS2 = SlitNew;
		m_iSlit1Adj = SlitNew;
		m_iSlit2Adj = SlitNew;
		break;
	}
	// Update the dialog
	UpdateData(FALSE);
}
