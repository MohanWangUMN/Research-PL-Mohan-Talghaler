// FilterDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DKA.h"
#include "FilterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFilterDlg dialog

extern int gblPortNo;
extern int count;
extern int in;
extern int out;
extern BYTE data[255];
extern int gblFilter;


CFilterDlg::CFilterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFilterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFilterDlg)
	m_iFilterCancel = 0;
	m_iFilterStatus = 0;
	m_lFilterTOut = 0;
	m_iNewFilter = 0;
	//}}AFX_DATA_INIT
}


void CFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFilterDlg)
	DDX_Control(pDX, IDOK, m_cOK);
	DDX_Text(pDX, IDC_FILTERCANCEL, m_iFilterCancel);
	DDX_Text(pDX, IDC_FILTERSTATUS, m_iFilterStatus);
	DDX_Text(pDX, IDC_FILTERTOUT, m_lFilterTOut);
	DDX_Control(pDX, IDC_MSCOMM1, m_Comm);
	DDX_Text(pDX, IDC_NEWFILTER, m_iNewFilter);
	DDV_MinMaxInt(pDX, m_iNewFilter, 1, 6);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFilterDlg, CDialog)
	//{{AFX_MSG_MAP(CFilterDlg)
	ON_EN_CHANGE(IDC_NEWFILTER, OnChangeNewfilter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFilterDlg message handlers


BOOL CFilterDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	m_Comm.SetCommPort(gblPortNo);
	m_Comm.SetSettings("9600,n,8,1");
	m_Comm.SetRTSEnable(TRUE);
	m_Comm.SetPortOpen(TRUE);
	m_Comm.SetInputMode(1);

	count=0;
	in=0;
	out=0;
	
	m_lFilterTOut=2;	// Initialize to 100s.
	m_iNewFilter=gblFilter;
	// Update the dialog
	UpdateData(FALSE);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}



int CFilterDlg::Buffer_Empty_Q()
{
	/* Return <> 0  if buffer is empty */
	return(count == 0);	
}

BYTE CFilterDlg::Dequeue_Buffer()
{
  /* Returns a byte from queue, MUST NOT BE EMPTY! */
  count--;
  out++;
  if ( out == 255 )
	 out = 0;
  return data[out] ;
}

void CFilterDlg::RcvCOM()
{
	COleVariant myVar;
	int hr;
	long lLen=0;
	myVar=m_Comm.GetInput();
	hr=SafeArrayGetUBound(myVar.parray, 1, &lLen);
	if( hr==S_OK)
	{
		lLen++;	//upper bound is zero based index
		// lock array so you can access it
		BYTE *pAccess;
		hr=SafeArrayAccessData(myVar.parray, (void**)&pAccess);

		if(hr==S_OK)
		{
			// Make a copy of data
			// Note: Need to check that lLen is < buffer length
			// so you don't overrun the buffer.
			for( int i=0; i<lLen; i++)
			{
				if(count<255)
				{
					count++;
					in++;
					if(in==255)
					  in=0;
					data[in]=pAccess[i];
				}
			}
			// unlock the data
			SafeArrayUnaccessData(myVar.parray);
		}
	}
}

void CFilterDlg::XmtCOM(unsigned char b)
{
	CByteArray arrBytes;
	arrBytes.Add(b);
	m_Comm.SetOutput(COleVariant(arrBytes));
}


void CFilterDlg::OnOK() 
{
	// TODO: Add extra validation here

	BYTE IDcmd, EchoB, StatusB;
	BYTE LoB;

	time_t start, finish;
	long timeout;
	double elapsed_time;

	// Update the variable
	UpdateData(TRUE);
	timeout=m_lFilterTOut;		//2s

	SetDlgItemText(IDC_SPEEDSTATUS,"0");
	SetDlgItemText(IDC_SPEEDCANCEL,"0");
	
	IDcmd=15;
	XmtCOM(IDcmd);
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while((Buffer_Empty_Q())&&(elapsed_time < timeout));
	if(elapsed_time < timeout)
	{
		EchoB=Dequeue_Buffer();
		if(EchoB != IDcmd)
		{
			MessageBox("An error has occurred !",
				"NO EchoByte",
				MB_ICONSTOP);
		}

		LoB=m_iNewFilter;
		XmtCOM(LoB);
		while(Buffer_Empty_Q())
			RcvCOM();
		StatusB=Dequeue_Buffer();
		m_iFilterStatus=StatusB;
		// Update dialog
		UpdateData(FALSE);

		while(Buffer_Empty_Q())
			RcvCOM();
		m_iFilterCancel=Dequeue_Buffer();
		// Update dialog
		UpdateData(FALSE);

		if (StatusB <= 127)
		{
			gblFilter = m_iNewFilter;
		}
		else
		{
			if ( (StatusB & 64)==0)
			MessageBox("An error has occurred !",
				"Status >= 128",
				MB_ICONSTOP);
			else
				gblFilter = m_iNewFilter;
		}


	//Time delay 1second
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while(elapsed_time < 1);
	XmtCOM(24);
	
	//Time delay 1second
	time( &start );
	do
	{
		RcvCOM();
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while(elapsed_time < 1);


	}
	else
	{
		MessageBox("Timeout !", "Timeout", MB_ICONSTOP);
	}
}


void CFilterDlg::OnChangeNewfilter() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here

	int NFilter;
	// Update variables
		UpdateData(TRUE);
	NFilter=m_iNewFilter;
	if(NFilter<0)
		m_iNewFilter=1;
	if(6<NFilter)
		m_iNewFilter=6;

		// Update dialog
		UpdateData(FALSE);
}
