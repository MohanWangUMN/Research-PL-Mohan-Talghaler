// ResetDlg.cpp : implementation file
//

#include "stdafx.h"
#include "DKA.h"
#include "ResetDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CResetDlg dialog

extern int gblPortNo;
extern int count;
extern int in;
extern int out;
extern BYTE data[255];
extern long gblCurWL;


CResetDlg::CResetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CResetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CResetDlg)
	//}}AFX_DATA_INIT
}


void CResetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CResetDlg)
	DDX_Control(pDX, IDC_OK, m_cOK);
	DDX_Control(pDX, IDC_PROGRESS1, m_cProgress);
	DDX_Control(pDX, IDC_MSCOMM1, m_Comm);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CResetDlg, CDialog)
	//{{AFX_MSG_MAP(CResetDlg)
	ON_BN_CLICKED(IDC_OK, OnOk)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CResetDlg message handlers


BOOL CResetDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here

	m_Comm.SetCommPort(gblPortNo);
	m_Comm.SetSettings("9600,n,8,1");
	m_Comm.SetRTSEnable(TRUE);
	m_Comm.SetPortOpen(TRUE);
	m_Comm.SetInputMode(1);

	count=0;
	in=0;
	out=0;

	m_cProgress.SetRange(0,10);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


int CResetDlg::Buffer_Empty_Q()
{
	/* Return <> 0  if buffer is empty */
	return(count == 0);	
}


BYTE CResetDlg::Dequeue_Buffer()
{
  /* Returns a byte from queue, MUST NOT BE EMPTY! */
  count--;
  out++;
  if ( out == 255 )
	 out = 0;
  return data[out] ;
}

void CResetDlg::RcvCOM()
{
	COleVariant myVar;
	int hr;
	long lLen=0;
	myVar=m_Comm.GetInput();
	hr=SafeArrayGetUBound(myVar.parray, 1, &lLen);
	if( hr==S_OK)
	{
		lLen++;	//upper bound is zero based index
		// lock array so you can access it
		BYTE *pAccess;
		hr=SafeArrayAccessData(myVar.parray, (void**)&pAccess);

		if(hr==S_OK)
		{
			// Make a copy of data
			// Note: Need to check that lLen is < buffer length
			// so you don't overrun the buffer.
			for( int i=0; i<lLen; i++)
			{
				if(count<255)
				{
					count++;
					in++;
					if(in==255)
					  in=0;
					data[in]=pAccess[i];
				}
			}
			// unlock the data
			SafeArrayUnaccessData(myVar.parray);
		}
	}
}

void CResetDlg::XmtCOM(unsigned char b)
{
	CByteArray arrBytes;
	arrBytes.Add(b);
	m_Comm.SetOutput(COleVariant(arrBytes));
}


void CResetDlg::OnOk() 
{
	// TODO: Add your control notification handler code here
	int i;

	time_t start, finish;
	long timeout;
	double elapsed_time;
	timeout=5;		//2s

	BYTE IDcmd, rtnB;
	//SetDlgItemText(IDC_RESETTING,"RESETTING...");
	m_cOK.EnableWindow(FALSE);
	m_cProgress.SetPos(1);	// Clear the progress bar

	IDcmd=255;
	XmtCOM(IDcmd); XmtCOM(IDcmd); XmtCOM(IDcmd);

	i=0;
	do
	{
	  time( &start );
	  do
	  {
		time( &finish );
		elapsed_time = difftime( finish, start );
		
	  }
	  while(elapsed_time < timeout);
	m_cProgress.SetPos(i+1);
	++i;
	if(i>10) i=0;
	rtnB=CheckEcho();
	}
	while(rtnB != 27);
	m_cProgress.SetPos(10);
	m_cOK.EnableWindow(TRUE);
	
}


BYTE CResetDlg::CheckEcho()
{
	// Return 0 if NO Echo byte; otherwise, it returns 27
	time_t start, finish;
	long timeout;
	double elapsed_time;
	timeout=2;		//2s
		
	BYTE rtnB;
	rtnB=0;

	XmtCOM(27);
	time( &start );
	do
	{
		time( &finish );
		elapsed_time = difftime( finish, start );
	}
	while(elapsed_time < timeout);

	if( Buffer_Empty_Q() )	// Return <> 0  if buffer is empty
		RcvCOM();
	if( !Buffer_Empty_Q() )
		rtnB=Dequeue_Buffer();

	return rtnB;
}

void CResetDlg::FlushRcv()
{
	BYTE rcvB;

	if( Buffer_Empty_Q() )	// Return <> 0  if buffer is empty
		RcvCOM();
	while( !Buffer_Empty_Q() )
		rcvB=Dequeue_Buffer();
	count=0; in=0; out=0;
}
