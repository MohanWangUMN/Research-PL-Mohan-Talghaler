//{{AFX_INCLUDES()
#include "mscomm.h"
//}}AFX_INCLUDES
#if !defined(AFX_SCANDLG_H__3A3B90B8_EC0B_4729_B882_FEC280ECD382__INCLUDED_)
#define AFX_SCANDLG_H__3A3B90B8_EC0B_4729_B882_FEC280ECD382__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ScanDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CScanDlg dialog

class CScanDlg : public CDialog
{
// Construction
public:
	CScanDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CScanDlg)
	enum { IDD = IDD_SCANDLG };
	CButton	m_cOK;
	CMSComm	m_Comm;
	int		m_iScanCancel;
	int		m_iScanStatus;
	long	m_lScanWL0;
	long	m_lScanWL1;
	long	m_lScanTOut;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScanDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CScanDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int Buffer_Empty_Q();
	BYTE Dequeue_Buffer();
	void XmtCOM(unsigned char);
	void RcvCOM();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCANDLG_H__3A3B90B8_EC0B_4729_B882_FEC280ECD382__INCLUDED_)
